package com.propertydealer.app.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.propertydealer.app.data.model.NegotiationEntry

@Dao
interface NegotiationDao {
    @Query("SELECT * FROM negotiation_history WHERE propertyId = :propertyId ORDER BY enteredAt ASC")
    fun getNegotiationsForProperty(propertyId: Long): LiveData<List<NegotiationEntry>>

    @Query("SELECT MAX(offeredPrice) FROM negotiation_history WHERE propertyId = :propertyId AND party = 'Buyer'")
    suspend fun getHighestBuyerOffer(propertyId: Long): Long?

    @Query("SELECT MIN(offeredPrice) FROM negotiation_history WHERE propertyId = :propertyId AND party = 'Seller'")
    suspend fun getLowestSellerAsk(propertyId: Long): Long?

    @Query("SELECT COUNT(*) FROM negotiation_history WHERE propertyId = :propertyId")
    suspend fun getRoundCount(propertyId: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: NegotiationEntry): Long

    @Delete
    suspend fun delete(entry: NegotiationEntry)
}
