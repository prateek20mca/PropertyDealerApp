package com.propertydealer.app.ui.property

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.propertydealer.app.R
import com.propertydealer.app.firebase.UserSession
import com.propertydealer.app.ui.auth.LoginActivity
import com.propertydealer.app.ui.guest.GuestHomeActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        Handler(Looper.getMainLooper()).postDelayed({
            when {
                UserSession.isDealer -> startActivity(Intent(this, MainActivity::class.java))
                UserSession.isGuest -> startActivity(Intent(this, GuestHomeActivity::class.java))
                else -> startActivity(Intent(this, LoginActivity::class.java))
            }
            finish()
        }, 1500)
    }
}
