package com.propertydealer.app.utils

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object FileUtils {

    fun createImageFile(context: Context, propertyId: Long): File {
        val dir = File(context.filesDir, "property_$propertyId/images").also { it.mkdirs() }
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        return File(dir, "IMG_${ts}_${System.nanoTime()}.jpg")
    }

    fun createPdfFile(context: Context, propertyId: Long): File {
        val dir = File(context.filesDir, "property_$propertyId/pdfs").also { it.mkdirs() }
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        return File(dir, "DOC_${ts}.pdf")
    }

    fun getFileName(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                cursor.moveToFirst()
                cursor.getString(nameIndex)
            }
        } catch (e: Exception) { null }
    }

    fun formatFileSize(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        else -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
    }

    fun isImage(mimeType: String) = mimeType.startsWith("image/")
    fun isPdf(mimeType: String) = mimeType == "application/pdf"
}
