package com.propertydealer.app.data.model

data class GuestSettings(
    val dealerId: String = "",
    val dealerName: String = "",
    val dealerPhone: String = "",
    val guestAccessCode: String = "",   // 6-digit code dealer shares with guests

    // ── What guests can see ───────────────────────────────────────────────────
    val showSellerName: Boolean = false,
    val showPhone: Boolean = false,     // always masked even if true
    val showExactAddress: Boolean = false,  // if false, only locality shown
    val showPrice: Boolean = true,
    val showPricePerSqYard: Boolean = true,
    val showSize: Boolean = true,
    val showFacing: Boolean = true,
    val showBuyerCount: Boolean = false,
    val showPropertyType: Boolean = true,
    val allowContactDealer: Boolean = true,

    val welcomeMessage: String = "Welcome! Browse available properties below.",
    val updatedAt: Long = System.currentTimeMillis()
)
