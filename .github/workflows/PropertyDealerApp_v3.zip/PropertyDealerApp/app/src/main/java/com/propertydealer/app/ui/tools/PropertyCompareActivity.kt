package com.propertydealer.app.ui.tools

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.propertydealer.app.data.model.Property
import com.propertydealer.app.databinding.ActivityPropertyCompareBinding
import com.propertydealer.app.ui.property.PropertyViewModel
import com.propertydealer.app.ui.property.PropertyViewModelFactory
import com.propertydealer.app.utils.FormatUtils

class PropertyCompareActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPropertyCompareBinding
    private val viewModel: PropertyViewModel by viewModels { PropertyViewModelFactory(application) }
    private var propertyA: Property? = null
    private var propertyB: Property? = null

    companion object {
        const val EXTRA_PROPERTY_A_ID = "extra_prop_a"
        const val EXTRA_PROPERTY_B_ID = "extra_prop_b"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPropertyCompareBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Compare Properties"
        binding.toolbar.setNavigationOnClickListener { finish() }

        val aId = intent.getLongExtra(EXTRA_PROPERTY_A_ID, 0L)
        val bId = intent.getLongExtra(EXTRA_PROPERTY_B_ID, 0L)

        if (aId > 0) viewModel.getPropertyById(aId) { propertyA = it; renderCompare() }
        if (bId > 0) viewModel.getPropertyById(bId) { propertyB = it; renderCompare() }

        binding.btnPickA.setOnClickListener { /* trigger picker */ }
        binding.btnPickB.setOnClickListener { /* trigger picker */ }
    }

    private fun renderCompare() {
        val a = propertyA
        val b = propertyB
        if (a == null && b == null) return

        binding.tableCompare.visibility = View.VISIBLE

        fun row(label: String, va: String, vb: String) {
            // Rows are pre-defined in XML; we populate by tag or programmatically
        }

        a?.let {
            binding.textAName.text = it.name
            binding.textAPrice.text = FormatUtils.formatCurrencyShort(it.totalPrice)
            binding.textAAskingPrice.text = FormatUtils.formatCurrencyShort(it.sellerAskingPrice)
            binding.textAArea.text = "${it.area} ${it.areaUnit}"
            binding.textAType.text = it.propertyType
            binding.textAStatus.text = it.status
            binding.textAFloor.text = it.floor.ifEmpty { "–" }
            binding.textAParking.text = if (it.parking) "Yes" else "No"
            binding.textAFurnished.text = it.furnished
            binding.textAFacing.text = it.facing.ifEmpty { "–" }
        }
        b?.let {
            binding.textBName.text = it.name
            binding.textBPrice.text = FormatUtils.formatCurrencyShort(it.totalPrice)
            binding.textBAskingPrice.text = FormatUtils.formatCurrencyShort(it.sellerAskingPrice)
            binding.textBArea.text = "${it.area} ${it.areaUnit}"
            binding.textBType.text = it.propertyType
            binding.textBStatus.text = it.status
            binding.textBFloor.text = it.floor.ifEmpty { "–" }
            binding.textBParking.text = if (it.parking) "Yes" else "No"
            binding.textBFurnished.text = it.furnished
            binding.textBFacing.text = it.facing.ifEmpty { "–" }
        }

        // Highlight winner
        if (a != null && b != null) {
            binding.textPriceWinner.text = if (a.totalPrice <= b.totalPrice)
                "✅ ${a.name} is cheaper" else "✅ ${b.name} is cheaper"
        }
    }
}
