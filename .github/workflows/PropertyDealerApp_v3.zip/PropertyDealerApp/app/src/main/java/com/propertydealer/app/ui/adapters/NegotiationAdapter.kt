package com.propertydealer.app.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.propertydealer.app.R
import com.propertydealer.app.data.model.NegotiationEntry
import com.propertydealer.app.utils.FormatUtils
import java.text.SimpleDateFormat
import java.util.*

class NegotiationAdapter(
    private val onDeleteClick: (NegotiationEntry) -> Unit
) : ListAdapter<NegotiationEntry, NegotiationAdapter.ViewHolder>(DiffCallback()) {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val textRound: TextView = view.findViewById(R.id.textNegRound)
        val textParty: TextView = view.findViewById(R.id.textNegParty)
        val textBuyer: TextView = view.findViewById(R.id.textNegBuyer)
        val textPrice: TextView = view.findViewById(R.id.textNegPrice)
        val textBreakdown: TextView = view.findViewById(R.id.textNegBreakdown)
        val textNotes: TextView = view.findViewById(R.id.textNegNotes)
        val textDate: TextView = view.findViewById(R.id.textNegDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_negotiation, parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = getItem(position)
        holder.textRound.text = "Round ${entry.round}"
        holder.textParty.text = entry.party
        holder.textBuyer.text = entry.buyerName
        holder.textPrice.text = FormatUtils.formatCurrencyShort(entry.offeredPrice)
        holder.textBreakdown.text = if (entry.whiteComponent > 0)
            "White: ${FormatUtils.formatCurrencyShort(entry.whiteComponent)}  Black: ${FormatUtils.formatCurrencyShort(entry.blackComponent)}"
        else ""
        holder.textNotes.text = entry.notes
        holder.textNotes.visibility = if (entry.notes.isEmpty()) View.GONE else View.VISIBLE
        holder.textDate.text = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(entry.enteredAt))

        val color = if (entry.party == "Buyer")
            ContextCompat.getColor(holder.itemView.context, R.color.colorAccent)
        else
            ContextCompat.getColor(holder.itemView.context, R.color.colorPrimary)
        holder.textParty.setTextColor(color)

        holder.itemView.setOnLongClickListener {
            onDeleteClick(entry)
            true
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<NegotiationEntry>() {
        override fun areItemsTheSame(a: NegotiationEntry, b: NegotiationEntry) = a.id == b.id
        override fun areContentsTheSame(a: NegotiationEntry, b: NegotiationEntry) = a == b
    }
}
