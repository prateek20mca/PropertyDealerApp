package com.propertydealer.app.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.propertydealer.app.R
import com.propertydealer.app.data.model.Appointment
import java.text.SimpleDateFormat
import java.util.*

class AppointmentAdapter(
    private val onEditClick: (Appointment) -> Unit,
    private val onDeleteClick: (Appointment) -> Unit,
    private val onCallClick: (Appointment) -> Unit,
    private val onStatusChange: (Appointment, String) -> Unit
) : ListAdapter<Appointment, AppointmentAdapter.ViewHolder>(DiffCallback()) {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val textDateTime: TextView = view.findViewById(R.id.textApptDateTime)
        val textBuyer: TextView = view.findViewById(R.id.textApptBuyer)
        val textPhone: TextView = view.findViewById(R.id.textApptPhone)
        val textProperty: TextView = view.findViewById(R.id.textApptProperty)
        val textType: TextView = view.findViewById(R.id.textApptType)
        val textStatus: TextView = view.findViewById(R.id.textApptStatus)
        val textNotes: TextView = view.findViewById(R.id.textApptNotes)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_appointment, parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val appt = getItem(position)
        val fmt = SimpleDateFormat("EEE, dd MMM yyyy  •  hh:mm a", Locale.getDefault())
        holder.textDateTime.text = fmt.format(Date(appt.scheduledAt))
        holder.textBuyer.text = appt.buyerName
        holder.textPhone.text = appt.buyerPhone
        holder.textProperty.text = appt.propertyName
        holder.textType.text = appt.visitType
        holder.textStatus.text = appt.status
        holder.textNotes.text = appt.notes.ifEmpty { "" }
        holder.textNotes.visibility = if (appt.notes.isEmpty()) View.GONE else View.VISIBLE

        val statusColor = when (appt.status) {
            "Completed" -> ContextCompat.getColor(holder.itemView.context, R.color.statusSold)
            "Cancelled" -> ContextCompat.getColor(holder.itemView.context, R.color.statusPending)
            else -> ContextCompat.getColor(holder.itemView.context, R.color.colorPrimary)
        }
        holder.textStatus.setTextColor(statusColor)

        holder.itemView.setOnLongClickListener {
            PopupMenu(it.context, it).apply {
                menu.add("Edit")
                menu.add("Call Buyer")
                menu.add("Mark Completed")
                menu.add("Mark Cancelled")
                menu.add("Delete")
                setOnMenuItemClickListener { item ->
                    when (item.title) {
                        "Edit" -> onEditClick(appt)
                        "Call Buyer" -> onCallClick(appt)
                        "Mark Completed" -> onStatusChange(appt, "Completed")
                        "Mark Cancelled" -> onStatusChange(appt, "Cancelled")
                        "Delete" -> onDeleteClick(appt)
                    }
                    true
                }
                show()
            }
            true
        }
        holder.textPhone.setOnClickListener { onCallClick(appt) }
    }

    class DiffCallback : DiffUtil.ItemCallback<Appointment>() {
        override fun areItemsTheSame(a: Appointment, b: Appointment) = a.id == b.id
        override fun areContentsTheSame(a: Appointment, b: Appointment) = a == b
    }
}
