package com.propertydealer.app.ui.buyer

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.propertydealer.app.data.db.AppDatabase
import com.propertydealer.app.data.model.Buyer
import com.propertydealer.app.databinding.ActivityAddBuyerBinding
import com.propertydealer.app.ui.property.PropertyViewModel
import com.propertydealer.app.ui.property.PropertyViewModelFactory
import com.propertydealer.app.utils.FormatUtils
import kotlinx.coroutines.launch

class AddBuyerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PROPERTY_ID = "extra_property_id"
        const val EXTRA_BUYER_ID = "extra_buyer_id"
    }

    private lateinit var binding: ActivityAddBuyerBinding
    private val viewModel: PropertyViewModel by viewModels {
        PropertyViewModelFactory(application)
    }

    private var propertyId: Long = -1L
    private var editBuyerId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddBuyerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        propertyId = intent.getLongExtra(EXTRA_PROPERTY_ID, -1L)
        editBuyerId = intent.getLongExtra(EXTRA_BUYER_ID, -1L)

        if (propertyId == -1L) {
            finish()
            return
        }

        val isEditing = editBuyerId != -1L
        setupToolbar(isEditing)
        setupDropdowns()

        if (isEditing) {
            loadBuyerForEdit()
        }

        binding.buttonSaveBuyer.setOnClickListener {
            saveBuyer()
        }
    }

    private fun setupToolbar(isEditing: Boolean) {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            title = if (isEditing) "Edit Buyer" else "Add Interested Buyer"
            setDisplayHomeAsUpEnabled(true)
        }
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupDropdowns() {
        val statusOptions = listOf("Interested", "Negotiating", "Accepted", "Rejected")
        binding.autoCompleteBuyerStatus.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, statusOptions)
        )
        binding.autoCompleteBuyerStatus.setText("Interested", false)
    }

    private fun loadBuyerForEdit() {
        lifecycleScope.launch {
            val db = AppDatabase.getDatabase(application)
            val buyer = db.buyerDao().getBuyerById(editBuyerId)
            buyer?.let { populateForm(it) }
        }
    }

    private fun populateForm(buyer: Buyer) {
        binding.editTextBuyerName.setText(buyer.name)
        binding.editTextBuyerPhone.setText(buyer.phone)
        binding.editTextBuyerEmail.setText(buyer.email)
        binding.editTextOfferedPrice.setText(buyer.offeredPrice.toString())
        binding.editTextOfferedWhitePrice.setText(if (buyer.offeredWhitePrice > 0) buyer.offeredWhitePrice.toString() else "")
        binding.editTextOfferedBlackPrice.setText(if (buyer.offeredBlackPrice > 0) buyer.offeredBlackPrice.toString() else "")
        binding.autoCompleteBuyerStatus.setText(buyer.status, false)
        binding.editTextBuyerNotes.setText(buyer.notes)
    }

    private fun saveBuyer() {
        val name = binding.editTextBuyerName.text.toString().trim()
        val phone = binding.editTextBuyerPhone.text.toString().trim()
        val offeredPriceStr = binding.editTextOfferedPrice.text.toString().trim()

        if (name.isEmpty()) {
            binding.tilBuyerName.error = "Buyer name is required"
            return
        }
        if (phone.isEmpty() || phone.length < 10) {
            binding.tilBuyerPhone.error = "Valid phone number required"
            return
        }
        if (offeredPriceStr.isEmpty()) {
            binding.tilOfferedPrice.error = "Offered price is required"
            return
        }

        binding.tilBuyerName.error = null
        binding.tilBuyerPhone.error = null
        binding.tilOfferedPrice.error = null

        val offeredPrice = FormatUtils.parseAmount(offeredPriceStr)
        val offeredWhite = FormatUtils.parseAmount(binding.editTextOfferedWhitePrice.text.toString())
        val offeredBlack = FormatUtils.parseAmount(binding.editTextOfferedBlackPrice.text.toString())

        val buyer = Buyer(
            id = if (editBuyerId != -1L) editBuyerId else 0L,
            propertyId = propertyId,
            name = name,
            phone = phone,
            email = binding.editTextBuyerEmail.text.toString().trim(),
            offeredPrice = offeredPrice,
            offeredWhitePrice = offeredWhite,
            offeredBlackPrice = offeredBlack,
            status = binding.autoCompleteBuyerStatus.text.toString(),
            notes = binding.editTextBuyerNotes.text.toString().trim()
        )

        if (editBuyerId != -1L) {
            viewModel.updateBuyer(buyer)
            Toast.makeText(this, "Buyer updated!", Toast.LENGTH_SHORT).show()
        } else {
            viewModel.insertBuyer(buyer)
            Toast.makeText(this, "Buyer added!", Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
