package com.propertydealer.app.firebase

import android.content.Context
import android.content.SharedPreferences

object UserSession {

    private const val PREF_NAME = "user_session"
    private const val KEY_USER_TYPE = "user_type"       // "dealer" or "guest"
    private const val KEY_REMEMBER_ME = "remember_me"
    private const val KEY_LAST_SEEN_AT = "last_seen_at"

    // Hardcoded dealer credentials
    const val DEALER_USER_ID = "admin"
    const val DEALER_PASSWORD = "Pc#pndt63"
    const val FIXED_DEALER_ID = "dealer_admin"  // Fixed Firestore document ID

    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    private var _userType: String
        get() = prefs.getString(KEY_USER_TYPE, "") ?: ""
        set(v) = prefs.edit().putString(KEY_USER_TYPE, v).apply()

    var rememberMe: Boolean
        get() = prefs.getBoolean(KEY_REMEMBER_ME, false)
        set(v) = prefs.edit().putBoolean(KEY_REMEMBER_ME, v).apply()

    var lastSeenPropertyAt: Long
        get() = prefs.getLong(KEY_LAST_SEEN_AT, System.currentTimeMillis())
        set(v) = prefs.edit().putLong(KEY_LAST_SEEN_AT, v).apply()

    val isDealer get() = _userType == "dealer"
    val isGuest get() = _userType == "guest"
    val isLoggedIn get() = _userType.isNotEmpty()

    fun loginAsDealer(remember: Boolean) {
        _userType = "dealer"
        rememberMe = remember
    }

    fun loginAsGuest() {
        _userType = "guest"
        lastSeenPropertyAt = System.currentTimeMillis()
    }

    fun logout() {
        // If remember me is ON, keep dealer logged in
        if (!rememberMe) {
            prefs.edit().remove(KEY_USER_TYPE).apply()
        }
    }

    fun forceLogout() {
        prefs.edit().clear().apply()
    }
}
