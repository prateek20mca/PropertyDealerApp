package com.propertydealer.app.utils

import com.propertydealer.app.data.model.Buyer
import com.propertydealer.app.data.model.Property

object ShareUtils {

    /**
     * Generate a share text for a property for buyers (masked seller info).
     */
    fun generateBuyerShareText(property: Property): String {
        val sb = StringBuilder()
        sb.appendLine("🏠 *PROPERTY FOR SALE*")
        sb.appendLine("━━━━━━━━━━━━━━━━━━━━")
        sb.appendLine()
        sb.appendLine("📋 *${property.name}*")
        sb.appendLine()
        sb.appendLine("📍 *Location:* ${property.address}")

        if (property.latitude != 0.0 && property.longitude != 0.0) {
            sb.appendLine("🗺️ *Map:* ${DistanceCalculator.buildMapsUrl(property.latitude, property.longitude, property.name)}")
        }

        sb.appendLine()
        sb.appendLine("💰 *Price Details:*")
        sb.appendLine("   Total Price: ${FormatUtils.formatCurrencyShort(property.totalPrice)}")
        if (property.whitePrice > 0)
            sb.appendLine("   White Amount: ${FormatUtils.formatCurrencyShort(property.whitePrice)}")
        if (property.blackPrice > 0)
            sb.appendLine("   Black Amount: ${FormatUtils.formatCurrencyShort(property.blackPrice)}")

        sb.appendLine()
        sb.appendLine("🏗️ *Property Details:*")
        sb.appendLine("   Type: ${property.propertyType}")
        if (property.area.isNotEmpty())
            sb.appendLine("   Area: ${property.area} ${property.areaUnit}")
        if (property.facing.isNotEmpty())
            sb.appendLine("   Facing: ${property.facing}")
        if (property.floor.isNotEmpty())
            sb.appendLine("   Floor: ${property.floor}${if (property.totalFloors.isNotEmpty()) "/${property.totalFloors}" else ""}")
        sb.appendLine("   Parking: ${if (property.parking) "Yes ✅" else "No ❌"}")
        sb.appendLine("   Furnished: ${property.furnished}")

        if (property.description.isNotEmpty()) {
            sb.appendLine()
            sb.appendLine("📝 *Description:*")
            sb.appendLine("   ${property.description}")
        }

        sb.appendLine()
        sb.appendLine("👤 *Seller Contact:*")
        sb.appendLine("   Name: ${property.sellerName}")
        // MASKED phone for buyers
        sb.appendLine("   Phone: ${FormatUtils.maskPhoneNumber(property.sellerPhone)} _(Contact dealer for full number)_")

        sb.appendLine()
        sb.appendLine("📞 *Contact dealer for more details & site visit.*")
        sb.appendLine()
        sb.appendLine("_Shared via Property Dealer App_")

        return sb.toString()
    }

    /**
     * Generate full property detail text for dealer's own reference (unmasked).
     */
    fun generateDealerShareText(property: Property, buyers: List<Buyer> = emptyList()): String {
        val sb = StringBuilder()
        sb.appendLine("🏠 *PROPERTY DETAIL REPORT*")
        sb.appendLine("━━━━━━━━━━━━━━━━━━━━━━━━━")
        sb.appendLine()
        sb.appendLine("📋 *${property.name}*")
        sb.appendLine("📅 Added: ${FormatUtils.formatDate(property.createdAt)}")
        sb.appendLine("🏷️ Status: ${property.status}")
        sb.appendLine()
        sb.appendLine("📍 *Location:* ${property.address}")

        if (property.latitude != 0.0 && property.longitude != 0.0) {
            sb.appendLine("🗺️ *Coordinates:* ${property.latitude}, ${property.longitude}")
            sb.appendLine("🗺️ *Map:* ${DistanceCalculator.buildMapsUrl(property.latitude, property.longitude, property.name)}")
        }

        sb.appendLine()
        sb.appendLine("💰 *Price Breakdown:*")
        sb.appendLine("   Total: ${FormatUtils.formatCurrency(property.totalPrice)}")
        sb.appendLine("   White: ${FormatUtils.formatCurrency(property.whitePrice)}")
        sb.appendLine("   Black: ${FormatUtils.formatCurrency(property.blackPrice)}")

        sb.appendLine()
        sb.appendLine("🏗️ *Property Info:*")
        sb.appendLine("   Type: ${property.propertyType}")
        if (property.area.isNotEmpty())
            sb.appendLine("   Area: ${property.area} ${property.areaUnit}")
        if (property.facing.isNotEmpty())
            sb.appendLine("   Facing: ${property.facing}")
        if (property.floor.isNotEmpty())
            sb.appendLine("   Floor: ${property.floor}${if (property.totalFloors.isNotEmpty()) "/${property.totalFloors}" else ""}")
        sb.appendLine("   Parking: ${if (property.parking) "Yes" else "No"}")
        sb.appendLine("   Furnished: ${property.furnished}")

        sb.appendLine()
        sb.appendLine("👤 *Seller Details (CONFIDENTIAL):*")
        sb.appendLine("   Name: ${property.sellerName}")
        sb.appendLine("   Phone: ${property.sellerPhone}")
        if (property.sellerAltPhone.isNotEmpty())
            sb.appendLine("   Alt Phone: ${property.sellerAltPhone}")
        if (property.sellerEmail.isNotEmpty())
            sb.appendLine("   Email: ${property.sellerEmail}")

        if (buyers.isNotEmpty()) {
            sb.appendLine()
            sb.appendLine("🧑‍💼 *Interested Buyers (${buyers.size}):*")
            buyers.forEachIndexed { i, buyer ->
                sb.appendLine()
                sb.appendLine("   Buyer ${i + 1}: ${buyer.name}")
                sb.appendLine("   Phone: ${buyer.phone}")
                sb.appendLine("   Offered: ${FormatUtils.formatCurrency(buyer.offeredPrice)}")
                sb.appendLine("   Status: ${buyer.status}")
                if (buyer.notes.isNotEmpty())
                    sb.appendLine("   Notes: ${buyer.notes}")
            }
        }

        if (property.notes.isNotEmpty()) {
            sb.appendLine()
            sb.appendLine("📝 *Notes:* ${property.notes}")
        }

        return sb.toString()
    }
}
