package com.propertydealer.app.data.model

data class Buyer(
    val id: String = "",
    val propertyId: String = "",
    val dealerId: String = "",
    val name: String = "",
    val phone: String = "",
    val email: String = "",
    val offeredPrice: Long = 0L,
    val offeredWhitePrice: Long = 0L,
    val offeredBlackPrice: Long = 0L,
    val offeredPricePerSqYard: Long = 0L,
    val status: String = "Interested",  // Interested, Negotiating, Accepted, Rejected
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
