package com.propertydealer.app.ui.property

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.propertydealer.app.R
import com.propertydealer.app.data.model.Buyer
import com.propertydealer.app.data.model.Property
import com.propertydealer.app.databinding.ActivityPropertyDetailBinding
import com.propertydealer.app.ui.adapters.BuyerAdapter
import com.propertydealer.app.ui.buyer.AddBuyerActivity
import com.propertydealer.app.utils.FormatUtils
import com.propertydealer.app.utils.ShareUtils

class PropertyDetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PROPERTY_ID = "extra_property_id"
    }

    private lateinit var binding: ActivityPropertyDetailBinding
    private val viewModel: PropertyViewModel by viewModels {
        PropertyViewModelFactory(application)
    }
    private lateinit var buyerAdapter: BuyerAdapter

    private var currentProperty: Property? = null
    private var currentBuyers: List<Buyer> = emptyList()
    private var propertyId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPropertyDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        propertyId = intent.getLongExtra(EXTRA_PROPERTY_ID, -1L)
        if (propertyId == -1L) {
            finish()
            return
        }

        setupToolbar()
        setupBuyerRecyclerView()
        setupButtons()
        observeProperty()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            title = "Property Details"
        }
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_property_detail, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_edit -> {
                val intent = Intent(this, AddEditPropertyActivity::class.java)
                intent.putExtra(AddEditPropertyActivity.EXTRA_PROPERTY_ID, propertyId)
                startActivity(intent)
                true
            }
            R.id.action_delete -> {
                confirmDelete()
                true
            }
            R.id.action_share_buyer -> {
                currentProperty?.let { shareToBuyer(it) }
                true
            }
            R.id.action_share_dealer -> {
                currentProperty?.let { shareAsDealer(it) }
                true
            }
            R.id.action_distance -> {
                currentProperty?.let {
                    val intent = Intent(this, DistanceCalculatorActivity::class.java)
                    intent.putExtra(DistanceCalculatorActivity.EXTRA_PROPERTY_LAT, it.latitude)
                    intent.putExtra(DistanceCalculatorActivity.EXTRA_PROPERTY_LON, it.longitude)
                    intent.putExtra(DistanceCalculatorActivity.EXTRA_PROPERTY_NAME, it.name)
                    intent.putExtra(DistanceCalculatorActivity.EXTRA_PROPERTY_ADDRESS, it.address)
                    startActivity(intent)
                }
                true
            }
            R.id.action_documents -> {
                currentProperty?.let {
                    startActivity(Intent(this, com.propertydealer.app.ui.document.DocumentManagerActivity::class.java).apply {
                        putExtra(com.propertydealer.app.ui.document.DocumentManagerActivity.EXTRA_PROPERTY_ID, it.id)
                        putExtra(com.propertydealer.app.ui.document.DocumentManagerActivity.EXTRA_PROPERTY_NAME, it.name)
                    })
                }
                true
            }
            R.id.action_appointments -> {
                currentProperty?.let {
                    startActivity(Intent(this, com.propertydealer.app.ui.appointment.AppointmentActivity::class.java).apply {
                        putExtra(com.propertydealer.app.ui.appointment.AppointmentActivity.EXTRA_PROPERTY_ID, it.id)
                        putExtra(com.propertydealer.app.ui.appointment.AppointmentActivity.EXTRA_PROPERTY_NAME, it.name)
                    })
                }
                true
            }
            R.id.action_negotiation -> {
                currentProperty?.let {
                    startActivity(Intent(this, com.propertydealer.app.ui.negotiation.NegotiationActivity::class.java).apply {
                        putExtra(com.propertydealer.app.ui.negotiation.NegotiationActivity.EXTRA_PROPERTY_ID, it.id)
                        putExtra(com.propertydealer.app.ui.negotiation.NegotiationActivity.EXTRA_PROPERTY_NAME, it.name)
                    })
                }
                true
            }
            R.id.action_compare -> {
                currentProperty?.let {
                    startActivity(Intent(this, com.propertydealer.app.ui.tools.PropertyCompareActivity::class.java).apply {
                        putExtra(com.propertydealer.app.ui.tools.PropertyCompareActivity.EXTRA_PROPERTY_A_ID, it.id)
                    })
                }
                true
            }
            R.id.action_full_report -> {
                currentProperty?.let { shareAsDealer(it) }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun setupBuyerRecyclerView() {
        buyerAdapter = BuyerAdapter(
            onEditClick = { buyer ->
                val intent = Intent(this, AddBuyerActivity::class.java)
                intent.putExtra(AddBuyerActivity.EXTRA_PROPERTY_ID, propertyId)
                intent.putExtra(AddBuyerActivity.EXTRA_BUYER_ID, buyer.id)
                startActivity(intent)
            },
            onDeleteClick = { buyer ->
                AlertDialog.Builder(this)
                    .setTitle("Delete Buyer")
                    .setMessage("Remove ${buyer.name} from interested buyers?")
                    .setPositiveButton("Delete") { _, _ ->
                        viewModel.deleteBuyer(buyer)
                        Snackbar.make(binding.root, "Buyer removed", Snackbar.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            },
            onCallClick = { buyer ->
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${buyer.phone}"))
                startActivity(intent)
            }
        )
        binding.recyclerViewBuyers.apply {
            layoutManager = LinearLayoutManager(this@PropertyDetailActivity)
            adapter = buyerAdapter
        }
    }

    private fun setupButtons() {
        binding.fabAddBuyer.setOnClickListener {
            val intent = Intent(this, AddBuyerActivity::class.java)
            intent.putExtra(AddBuyerActivity.EXTRA_PROPERTY_ID, propertyId)
            startActivity(intent)
        }

        binding.buttonCallSeller.setOnClickListener {
            currentProperty?.let {
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${it.sellerPhone}"))
                startActivity(intent)
            }
        }

        binding.buttonViewOnMap.setOnClickListener {
            currentProperty?.let {
                if (it.latitude != 0.0 && it.longitude != 0.0) {
                    val uri = Uri.parse("geo:${it.latitude},${it.longitude}?q=${it.latitude},${it.longitude}(${it.name})")
                    val intent = Intent(Intent.ACTION_VIEW, uri)
                    if (intent.resolveActivity(packageManager) != null) {
                        startActivity(intent)
                    } else {
                        val browserUri = Uri.parse("https://maps.google.com/?q=${it.latitude},${it.longitude}")
                        startActivity(Intent(Intent.ACTION_VIEW, browserUri))
                    }
                } else {
                    val uri = Uri.parse("geo:0,0?q=${Uri.encode(it.address)}")
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                }
            }
        }

        binding.buttonCheckDistance.setOnClickListener {
            currentProperty?.let {
                val intent = Intent(this, DistanceCalculatorActivity::class.java)
                intent.putExtra(DistanceCalculatorActivity.EXTRA_PROPERTY_LAT, it.latitude)
                intent.putExtra(DistanceCalculatorActivity.EXTRA_PROPERTY_LON, it.longitude)
                intent.putExtra(DistanceCalculatorActivity.EXTRA_PROPERTY_NAME, it.name)
                intent.putExtra(DistanceCalculatorActivity.EXTRA_PROPERTY_ADDRESS, it.address)
                startActivity(intent)
            }
        }
    }

    private fun observeProperty() {
        val db = com.propertydealer.app.data.db.AppDatabase.getDatabase(application)
        db.propertyDao().getPropertyByIdLive(propertyId).observe(this) { property ->
            property?.let {
                currentProperty = it
                populateUI(it)
            }
        }

        viewModel.getBuyersForProperty(propertyId).observe(this) { buyers ->
            currentBuyers = buyers
            buyerAdapter.submitList(buyers)
            binding.textViewBuyerCount.text = "${buyers.size} Interested Buyer(s)"
            binding.textViewNoBuyers.visibility = if (buyers.isEmpty()) View.VISIBLE else View.GONE

            if (buyers.isNotEmpty()) {
                val highest = buyers.maxByOrNull { it.offeredPrice }
                binding.textViewHighestOffer.text =
                    "Highest Offer: ${FormatUtils.formatCurrencyShort(highest?.offeredPrice ?: 0)}"
                binding.textViewHighestOffer.visibility = View.VISIBLE
            } else {
                binding.textViewHighestOffer.visibility = View.GONE
            }
        }
    }

    private fun populateUI(property: Property) {
        binding.textViewPropertyName.text = property.name
        binding.textViewAddress.text = property.address
        binding.textViewStatus.text = property.status
        binding.textViewStatus.setTextColor(ContextCompat.getColor(this, FormatUtils.getStatusColor(property.status)))

        binding.textViewTotalPrice.text = FormatUtils.formatCurrency(property.totalPrice)
        binding.textViewTotalPriceShort.text = FormatUtils.formatCurrencyShort(property.totalPrice)
        binding.textViewWhitePrice.text = FormatUtils.formatCurrency(property.whitePrice)
        binding.textViewBlackPrice.text = FormatUtils.formatCurrency(property.blackPrice)

        binding.textViewPropertyType.text = property.propertyType
        binding.textViewArea.text = if (property.area.isNotEmpty()) "${property.area} ${property.areaUnit}" else "N/A"
        binding.textViewFacing.text = if (property.facing.isNotEmpty()) property.facing else "N/A"
        binding.textViewFloor.text = if (property.floor.isNotEmpty()) {
            "${property.floor}${if (property.totalFloors.isNotEmpty()) " / ${property.totalFloors}" else ""}"
        } else "N/A"
        binding.textViewParking.text = if (property.parking) "Yes ✅" else "No ❌"
        binding.textViewFurnished.text = property.furnished

        binding.textViewSellerName.text = property.sellerName
        binding.textViewSellerPhone.text = property.sellerPhone
        binding.textViewSellerAltPhone.text = if (property.sellerAltPhone.isNotEmpty()) property.sellerAltPhone else "N/A"
        binding.textViewSellerEmail.text = if (property.sellerEmail.isNotEmpty()) property.sellerEmail else "N/A"

        if (property.latitude != 0.0 && property.longitude != 0.0) {
            binding.textViewCoordinates.text = "${property.latitude}, ${property.longitude}"
            binding.cardCoordinates.visibility = View.VISIBLE
        } else {
            binding.cardCoordinates.visibility = View.GONE
        }

        binding.textViewDescription.text = if (property.description.isNotEmpty()) property.description else "No description"
        binding.textViewNotes.text = if (property.notes.isNotEmpty()) property.notes else "No notes"
        binding.textViewCreatedDate.text = "Added: ${FormatUtils.formatDateTime(property.createdAt)}"
        binding.textViewUpdatedDate.text = "Updated: ${FormatUtils.formatDateTime(property.updatedAt)}"
    }

    private fun shareToBuyer(property: Property) {
        val shareText = ShareUtils.generateBuyerShareText(property)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        startActivity(Intent.createChooser(intent, "Share Property Details (Buyer View)"))
    }

    private fun shareAsDealer(property: Property) {
        val shareText = ShareUtils.generateDealerShareText(property, currentBuyers)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        startActivity(Intent.createChooser(intent, "Share Full Property Report"))
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle("Delete Property")
            .setMessage("Are you sure you want to delete '${currentProperty?.name}'? This will also delete all buyer records.")
            .setPositiveButton("Delete") { _, _ ->
                currentProperty?.let {
                    viewModel.deleteProperty(it)
                    finish()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
