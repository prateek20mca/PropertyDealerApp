package com.propertydealer.app.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.propertydealer.app.data.model.PropertyDocument

@Dao
interface DocumentDao {
    @Query("SELECT * FROM property_documents WHERE propertyId = :propertyId ORDER BY isCover DESC, uploadedAt DESC")
    fun getDocumentsForProperty(propertyId: Long): LiveData<List<PropertyDocument>>

    @Query("SELECT * FROM property_documents WHERE propertyId = :propertyId AND fileType LIKE 'image/%' ORDER BY isCover DESC, uploadedAt DESC")
    fun getImagesForProperty(propertyId: Long): LiveData<List<PropertyDocument>>

    @Query("SELECT * FROM property_documents WHERE propertyId = :propertyId AND fileType = 'application/pdf' ORDER BY uploadedAt DESC")
    fun getPdfsForProperty(propertyId: Long): LiveData<List<PropertyDocument>>

    @Query("SELECT * FROM property_documents WHERE propertyId = :propertyId AND isCover = 1 LIMIT 1")
    suspend fun getCoverImage(propertyId: Long): PropertyDocument?

    @Query("SELECT COUNT(*) FROM property_documents WHERE propertyId = :propertyId")
    suspend fun getDocumentCount(propertyId: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(document: PropertyDocument): Long

    @Update
    suspend fun update(document: PropertyDocument)

    @Delete
    suspend fun delete(document: PropertyDocument)

    @Query("UPDATE property_documents SET isCover = 0 WHERE propertyId = :propertyId")
    suspend fun clearCoverForProperty(propertyId: Long)

    @Query("SELECT * FROM property_documents WHERE propertyId = :propertyId AND docCategory = :category ORDER BY uploadedAt DESC")
    fun getDocumentsByCategory(propertyId: Long, category: String): LiveData<List<PropertyDocument>>
}
