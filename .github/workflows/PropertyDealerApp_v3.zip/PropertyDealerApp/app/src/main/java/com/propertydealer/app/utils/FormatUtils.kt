package com.propertydealer.app.utils

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

object FormatUtils {

    private val currencyFormat = NumberFormat.getInstance(Locale("en", "IN"))

    /**
     * Format a long amount to Indian currency format (e.g. ₹12,50,000)
     */
    fun formatCurrency(amount: Long): String {
        return "₹${currencyFormat.format(amount)}"
    }

    /**
     * Format amount to short form (e.g. 12.5L, 2.5Cr)
     */
    fun formatCurrencyShort(amount: Long): String {
        return when {
            amount >= 10_000_000 -> {
                val cr = amount / 10_000_000.0
                "₹${"%.2f".format(cr)} Cr"
            }
            amount >= 100_000 -> {
                val lakh = amount / 100_000.0
                "₹${"%.2f".format(lakh)} L"
            }
            amount >= 1_000 -> {
                val k = amount / 1_000.0
                "₹${"%.1f".format(k)} K"
            }
            else -> "₹$amount"
        }
    }

    /**
     * Mask phone number for sharing with buyers.
     * e.g. 9876543210 → 98765XXXXX
     */
    fun maskPhoneNumber(phone: String): String {
        if (phone.length < 5) return "XXXXX"
        val visible = phone.take(5)
        val masked = "X".repeat(phone.length - 5)
        return visible + masked
    }

    /**
     * Partially mask phone for display (shows last 2 digits too)
     * e.g. 9876543210 → 987XX3210  
     */
    fun maskPhoneMiddle(phone: String): String {
        if (phone.length < 7) return maskPhoneNumber(phone)
        val prefix = phone.take(3)
        val suffix = phone.takeLast(4)
        val masked = "X".repeat(phone.length - 7)
        return "$prefix$masked$suffix"
    }

    /**
     * Format date from timestamp
     */
    fun formatDate(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    /**
     * Format date and time from timestamp
     */
    fun formatDateTime(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    /**
     * Parse amount string to Long (supports commas)
     */
    fun parseAmount(input: String): Long {
        return try {
            input.replace(",", "").replace("₹", "").trim().toLong()
        } catch (e: NumberFormatException) {
            0L
        }
    }

    /**
     * Get status color resource based on status string
     */
    fun getStatusColor(status: String): Int {
        return when (status.lowercase()) {
            "available" -> android.R.color.holo_green_dark
            "sold" -> android.R.color.holo_red_dark
            "pending" -> android.R.color.holo_orange_dark
            "under negotiation" -> android.R.color.holo_blue_dark
            else -> android.R.color.darker_gray
        }
    }

    /**
     * Get buyer status color
     */
    fun getBuyerStatusColor(status: String): Int {
        return when (status.lowercase()) {
            "interested" -> android.R.color.holo_blue_dark
            "negotiating" -> android.R.color.holo_orange_dark
            "accepted" -> android.R.color.holo_green_dark
            "rejected" -> android.R.color.holo_red_dark
            else -> android.R.color.darker_gray
        }
    }
}
