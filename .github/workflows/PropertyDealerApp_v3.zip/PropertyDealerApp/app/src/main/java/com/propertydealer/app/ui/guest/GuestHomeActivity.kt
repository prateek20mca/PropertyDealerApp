package com.propertydealer.app.ui.guest

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.propertydealer.app.R
import com.propertydealer.app.data.model.GuestSettings
import com.propertydealer.app.data.model.Property
import com.propertydealer.app.databinding.ActivityGuestHomeBinding
import com.propertydealer.app.firebase.FirebaseRepository
import com.propertydealer.app.firebase.UserSession
import com.propertydealer.app.ui.adapters.GuestPropertyAdapter
import com.propertydealer.app.ui.auth.LoginActivity
import com.google.firebase.firestore.ListenerRegistration

class GuestHomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGuestHomeBinding
    private lateinit var adapter: GuestPropertyAdapter
    private var guestSettings: GuestSettings? = null
    private var propertyListener: ListenerRegistration? = null
    private var settingsListener: ListenerRegistration? = null
    private var newPropertyListener: ListenerRegistration? = null
    private val dealerId = UserSession.FIXED_DEALER_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGuestHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = "Available Properties"

        createNotificationChannel()
        setupAdapter()
        listenToSettings()
        listenToProperties()
        listenForNewProperties()
    }

    private fun setupAdapter() {
        adapter = GuestPropertyAdapter { property ->
            val intent = Intent(this, GuestPropertyDetailActivity::class.java)
            intent.putExtra(GuestPropertyDetailActivity.EXTRA_PROPERTY_ID, property.id)
            intent.putExtra(GuestPropertyDetailActivity.EXTRA_DEALER_ID, dealerId)
            startActivity(intent)
        }
        binding.recyclerProperties.apply {
            layoutManager = LinearLayoutManager(this@GuestHomeActivity)
            adapter = this@GuestHomeActivity.adapter
        }
    }

    private fun listenToSettings() {
        settingsListener = FirebaseRepository.listenToGuestSettings() { settings ->
            guestSettings = settings
            supportActionBar?.title = settings.dealerName.ifEmpty { "Available Properties" }
            supportActionBar?.subtitle = settings.welcomeMessage.ifEmpty { null }
            adapter.updateSettings(settings)
        }
    }

    private fun listenToProperties() {
        binding.progressBar.visibility = View.VISIBLE
        propertyListener = FirebaseRepository.listenToProperties() { properties ->
            binding.progressBar.visibility = View.GONE
            val available = properties.filter { it.status == "Available" || it.status == "Under Negotiation" }
            adapter.submitList(available)
            binding.textEmpty.visibility = if (available.isEmpty()) View.VISIBLE else View.GONE
            binding.textCount.text = "${available.size} properties available"
        }
    }

    private fun listenForNewProperties() {
        newPropertyListener = FirebaseRepository.listenForNewProperties(
            UserSession.lastSeenPropertyAt
        ) { newProperty ->
            UserSession.lastSeenPropertyAt = System.currentTimeMillis()
            showNewPropertyNotification(newProperty)
        }
    }

    private fun showNewPropertyNotification(property: Property) {
        val intent = Intent(this, GuestHomeActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, "new_property")
            .setSmallIcon(R.drawable.ic_property)
            .setContentTitle("🏠 New Property Available!")
            .setContentText("${property.locality.ifEmpty { "New property" }} — ${property.propertyType}")
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText("A new ${property.propertyType} is now listed in ${property.locality}. Tap to view details."))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()
        try {
            NotificationManagerCompat.from(this).notify(property.id.hashCode(), notification)
        } catch (e: SecurityException) { /* notification permission not granted */ }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "new_property", "New Properties", NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Notifications for new property listings" }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Contact Dealer")
        menu.add(0, 2, 1, "Logout")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            1 -> {
                guestSettings?.let {
                    if (it.allowContactDealer && it.dealerPhone.isNotEmpty()) {
                        startActivity(Intent(Intent.ACTION_DIAL,
                            android.net.Uri.parse("tel:${it.dealerPhone}")))
                    } else {
                        android.widget.Toast.makeText(this, "Contact not available", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
                true
            }
            2 -> {
                AlertDialog.Builder(this)
                    .setTitle("Logout?")
                    .setMessage("You will need the access code to login again.")
                    .setPositiveButton("Logout") { _, _ ->
                        UserSession.forceLogout()
                        startActivity(Intent(this, LoginActivity::class.java))
                        finish()
                    }
                    .setNegativeButton("Cancel", null).show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        propertyListener?.remove()
        settingsListener?.remove()
        newPropertyListener?.remove()
    }
}
