package com.propertydealer.app.data.model

data class Appointment(
    val id: String = "",
    val propertyId: String = "",
    val propertyName: String = "",
    val dealerId: String = "",
    val buyerName: String = "",
    val buyerPhone: String = "",
    val scheduledAt: Long = 0L,
    val visitType: String = "Site Visit",
    val status: String = "Scheduled",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
