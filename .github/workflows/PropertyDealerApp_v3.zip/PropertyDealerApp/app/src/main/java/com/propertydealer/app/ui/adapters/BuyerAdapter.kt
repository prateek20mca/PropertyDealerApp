package com.propertydealer.app.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.propertydealer.app.data.model.Buyer
import com.propertydealer.app.databinding.ItemBuyerBinding
import com.propertydealer.app.utils.FormatUtils

class BuyerAdapter(
    private val onEditClick: (Buyer) -> Unit,
    private val onDeleteClick: (Buyer) -> Unit,
    private val onCallClick: (Buyer) -> Unit
) : ListAdapter<Buyer, BuyerAdapter.BuyerViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BuyerViewHolder {
        val binding = ItemBuyerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return BuyerViewHolder(binding)
    }

    override fun onBindViewHolder(holder: BuyerViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class BuyerViewHolder(private val binding: ItemBuyerBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(buyer: Buyer) {
            binding.textViewBuyerName.text = buyer.name
            binding.textViewBuyerPhone.text = buyer.phone
            binding.textViewOfferedPrice.text = FormatUtils.formatCurrencyShort(buyer.offeredPrice)
            binding.textViewBuyerStatus.text = buyer.status
            binding.textViewBuyerStatus.setTextColor(
                ContextCompat.getColor(binding.root.context, FormatUtils.getBuyerStatusColor(buyer.status))
            )
            binding.textViewBuyerDate.text = FormatUtils.formatDate(buyer.createdAt)

            if (buyer.notes.isNotEmpty()) {
                binding.textViewBuyerNotes.text = buyer.notes
                binding.textViewBuyerNotes.visibility = android.view.View.VISIBLE
            } else {
                binding.textViewBuyerNotes.visibility = android.view.View.GONE
            }

            if (buyer.offeredWhitePrice > 0) {
                binding.textViewOfferedBreakdown.text =
                    "W: ${FormatUtils.formatCurrencyShort(buyer.offeredWhitePrice)} | B: ${FormatUtils.formatCurrencyShort(buyer.offeredBlackPrice)}"
                binding.textViewOfferedBreakdown.visibility = android.view.View.VISIBLE
            } else {
                binding.textViewOfferedBreakdown.visibility = android.view.View.GONE
            }

            binding.buttonCallBuyer.setOnClickListener { onCallClick(buyer) }
            binding.buttonEditBuyer.setOnClickListener { onEditClick(buyer) }
            binding.buttonDeleteBuyer.setOnClickListener { onDeleteClick(buyer) }
        }
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Buyer>() {
            override fun areItemsTheSame(oldItem: Buyer, newItem: Buyer) =
                oldItem.id == newItem.id

            override fun areContentsTheSame(oldItem: Buyer, newItem: Buyer) =
                oldItem == newItem
        }
    }
}
