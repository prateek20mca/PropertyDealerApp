package com.propertydealer.app.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.propertydealer.app.data.model.Buyer

@Dao
interface BuyerDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(buyer: Buyer): Long

    @Update
    suspend fun update(buyer: Buyer)

    @Delete
    suspend fun delete(buyer: Buyer)

    @Query("SELECT * FROM buyers WHERE propertyId = :propertyId ORDER BY createdAt DESC")
    fun getBuyersForProperty(propertyId: Long): LiveData<List<Buyer>>

    @Query("SELECT * FROM buyers WHERE id = :id")
    suspend fun getBuyerById(id: Long): Buyer?

    @Query("SELECT COUNT(*) FROM buyers WHERE propertyId = :propertyId")
    suspend fun getBuyerCountForProperty(propertyId: Long): Int

    @Query("SELECT MAX(offeredPrice) FROM buyers WHERE propertyId = :propertyId")
    suspend fun getHighestOfferForProperty(propertyId: Long): Long?

    @Query("""
        SELECT * FROM buyers WHERE 
        name LIKE '%' || :query || '%' OR 
        phone LIKE '%' || :query || '%'
    """)
    fun searchBuyers(query: String): LiveData<List<Buyer>>
}
