package com.propertydealer.app.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.propertydealer.app.R
import com.propertydealer.app.data.model.PropertyDocument
import com.propertydealer.app.utils.FileUtils
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class DocumentAdapter(
    private val onImageClick: (PropertyDocument) -> Unit,
    private val onDeleteClick: (PropertyDocument) -> Unit,
    private val onSetCoverClick: (PropertyDocument) -> Unit,
    private val onShareClick: (PropertyDocument) -> Unit
) : ListAdapter<PropertyDocument, DocumentAdapter.ViewHolder>(DiffCallback()) {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imagePreview: ImageView = view.findViewById(R.id.imageDocPreview)
        val textName: TextView = view.findViewById(R.id.textDocName)
        val textMeta: TextView = view.findViewById(R.id.textDocMeta)
        val textCategory: TextView = view.findViewById(R.id.textDocCategory)
        val badgeCover: TextView = view.findViewById(R.id.badgeCover)
        val btnMenu: ImageView = view.findViewById(R.id.btnDocMenu)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_document, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val doc = getItem(position)
        holder.textName.text = doc.fileName
        holder.textMeta.text = "${FileUtils.formatFileSize(doc.fileSize)} · ${
            SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(doc.uploadedAt))}"
        holder.textCategory.text = doc.docCategory
        holder.badgeCover.visibility = if (doc.isCover) View.VISIBLE else View.GONE

        // Show thumbnail or PDF icon
        if (FileUtils.isImage(doc.fileType)) {
            val file = File(doc.filePath)
            if (file.exists()) {
                holder.imagePreview.setImageURI(android.net.Uri.fromFile(file))
            } else {
                holder.imagePreview.setImageResource(R.drawable.ic_property)
            }
        } else {
            holder.imagePreview.setImageResource(R.drawable.ic_pdf)
        }

        holder.itemView.setOnClickListener { onImageClick(doc) }
        holder.btnMenu.setOnClickListener { v ->
            PopupMenu(v.context, v).apply {
                menu.add(0, 0, 0, "Open")
                menu.add(0, 1, 1, "Share")
                if (FileUtils.isImage(doc.fileType)) menu.add(0, 2, 2, "Set as Cover Photo")
                menu.add(0, 3, 3, "Delete")
                setOnMenuItemClickListener { item ->
                    when (item.itemId) {
                        0 -> onImageClick(doc)
                        1 -> onShareClick(doc)
                        2 -> onSetCoverClick(doc)
                        3 -> onDeleteClick(doc)
                    }
                    true
                }
                show()
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<PropertyDocument>() {
        override fun areItemsTheSame(a: PropertyDocument, b: PropertyDocument) = a.id == b.id
        override fun areContentsTheSame(a: PropertyDocument, b: PropertyDocument) = a == b
    }
}
