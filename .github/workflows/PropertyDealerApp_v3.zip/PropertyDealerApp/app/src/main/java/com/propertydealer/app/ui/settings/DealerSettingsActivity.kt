package com.propertydealer.app.ui.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.propertydealer.app.data.model.GuestSettings
import com.propertydealer.app.databinding.ActivityDealerSettingsBinding
import com.propertydealer.app.firebase.FirebaseRepository
import com.propertydealer.app.firebase.UserSession
import kotlinx.coroutines.launch

class DealerSettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDealerSettingsBinding
    private var currentSettings: GuestSettings? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDealerSettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Guest Access Settings"
        binding.toolbar.setNavigationOnClickListener { finish() }

        loadSettings()

        binding.btnCopyCode.setOnClickListener {
            val code = binding.textGuestCode.text.toString()
            val clipboard = getSystemService(ClipboardManager::class.java)
            clipboard?.setPrimaryClip(ClipData.newPlainText("Guest Code", code))
            Toast.makeText(this, "Code copied! Share it with your guests.", Toast.LENGTH_SHORT).show()
        }

        binding.btnRegenerateCode.setOnClickListener {
            val newCode = (100000..999999).random().toString()
            binding.textGuestCode.text = newCode
            currentSettings = currentSettings?.copy(guestAccessCode = newCode)
            Toast.makeText(this, "New code generated. Save settings to apply.", Toast.LENGTH_SHORT).show()
        }

        binding.btnSaveSettings.setOnClickListener { saveSettings() }
    }

    private fun loadSettings() {
        lifecycleScope.launch {
            val settings = FirebaseRepository.getGuestSettings()
            settings?.let { populateForm(it) }
            currentSettings = settings ?: GuestSettings(
                dealerId = com.propertydealer.app.firebase.UserSession.FIXED_DEALER_ID,
                guestAccessCode = (100000..999999).random().toString()
            )
        }
    }

    private fun populateForm(s: GuestSettings) {
        binding.textGuestCode.text = s.guestAccessCode
        binding.etDealerName.setText(s.dealerName)
        binding.etDealerPhone.setText(s.dealerPhone)
        binding.etWelcomeMessage.setText(s.welcomeMessage)
        binding.switchShowSellerName.isChecked = s.showSellerName
        binding.switchShowPhone.isChecked = s.showPhone
        binding.switchShowExactAddress.isChecked = s.showExactAddress
        binding.switchShowPrice.isChecked = s.showPrice
        binding.switchShowPricePerSqYard.isChecked = s.showPricePerSqYard
        binding.switchShowSize.isChecked = s.showSize
        binding.switchShowFacing.isChecked = s.showFacing
        binding.switchShowBuyerCount.isChecked = s.showBuyerCount
        binding.switchAllowContact.isChecked = s.allowContactDealer
    }

    private fun saveSettings() {
        val settings = GuestSettings(
            dealerId = com.propertydealer.app.firebase.UserSession.FIXED_DEALER_ID,
            dealerName = binding.etDealerName.text.toString().trim(),
            dealerPhone = binding.etDealerPhone.text.toString().trim(),
            guestAccessCode = binding.textGuestCode.text.toString(),
            welcomeMessage = binding.etWelcomeMessage.text.toString().trim(),
            showSellerName = binding.switchShowSellerName.isChecked,
            showPhone = binding.switchShowPhone.isChecked,
            showExactAddress = binding.switchShowExactAddress.isChecked,
            showPrice = binding.switchShowPrice.isChecked,
            showPricePerSqYard = binding.switchShowPricePerSqYard.isChecked,
            showSize = binding.switchShowSize.isChecked,
            showFacing = binding.switchShowFacing.isChecked,
            showBuyerCount = binding.switchShowBuyerCount.isChecked,
            allowContactDealer = binding.switchAllowContact.isChecked
        )
        lifecycleScope.launch {
            val result = FirebaseRepository.saveGuestSettings(settings)
            result.onSuccess {
                Toast.makeText(this@DealerSettingsActivity, "Settings saved!", Toast.LENGTH_SHORT).show()
                finish()
            }.onFailure {
                Toast.makeText(this@DealerSettingsActivity, "Error: ${it.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
