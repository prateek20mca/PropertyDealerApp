package com.propertydealer.app.ui.appointment

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.propertydealer.app.data.model.Appointment
import com.propertydealer.app.databinding.ActivityAppointmentBinding
import com.propertydealer.app.ui.adapters.AppointmentAdapter
import com.propertydealer.app.ui.property.PropertyViewModel
import com.propertydealer.app.ui.property.PropertyViewModelFactory
import java.text.SimpleDateFormat
import java.util.*

class AppointmentActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PROPERTY_ID = "extra_property_id"
        const val EXTRA_PROPERTY_NAME = "extra_property_name"
        const val MODE_ALL = "all"
    }

    private lateinit var binding: ActivityAppointmentBinding
    private val viewModel: PropertyViewModel by viewModels { PropertyViewModelFactory(application) }
    private lateinit var adapter: AppointmentAdapter
    private var propertyId: Long = 0L
    private var propertyName: String = ""
    private var scheduledCalendar = Calendar.getInstance()
    private var isAllMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppointmentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        propertyId = intent.getLongExtra(EXTRA_PROPERTY_ID, 0L)
        propertyName = intent.getStringExtra(EXTRA_PROPERTY_NAME) ?: ""
        isAllMode = intent.getStringExtra("mode") == MODE_ALL

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = if (isAllMode) "All Appointments" else "Site Visits"
        if (!isAllMode) supportActionBar?.subtitle = propertyName
        binding.toolbar.setNavigationOnClickListener { finish() }

        setupAdapter()
        loadAppointments()

        binding.fabAddAppointment.setOnClickListener { showAddDialog() }
    }

    private fun setupAdapter() {
        adapter = AppointmentAdapter(
            onEditClick = { showEditDialog(it) },
            onDeleteClick = { confirmDelete(it) },
            onCallClick = { appt ->
                startActivity(Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:${appt.buyerPhone}")))
            },
            onStatusChange = { appt, status ->
                viewModel.updateAppointment(appt.copy(status = status))
            }
        )
        binding.recyclerAppointments.apply {
            layoutManager = LinearLayoutManager(this@AppointmentActivity)
            adapter = this@AppointmentActivity.adapter
        }
    }

    private fun loadAppointments() {
        val liveData = if (isAllMode) viewModel.getAllAppointments()
                       else viewModel.getAppointmentsForProperty(propertyId)
        liveData.observe(this) { list ->
            adapter.submitList(list)
            binding.textViewEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun showAddDialog(existing: Appointment? = null) {
        val dialogBinding = layoutInflater.inflate(
            com.propertydealer.app.R.layout.dialog_add_appointment, null)

        val etBuyerName = dialogBinding.findViewById<com.google.android.material.textfield.TextInputEditText>(
            com.propertydealer.app.R.id.etApptBuyerName)
        val etBuyerPhone = dialogBinding.findViewById<com.google.android.material.textfield.TextInputEditText>(
            com.propertydealer.app.R.id.etApptBuyerPhone)
        val btnDate = dialogBinding.findViewById<android.widget.Button>(com.propertydealer.app.R.id.btnApptDate)
        val btnTime = dialogBinding.findViewById<android.widget.Button>(com.propertydealer.app.R.id.btnApptTime)
        val spinnerType = dialogBinding.findViewById<android.widget.Spinner>(com.propertydealer.app.R.id.spinnerApptType)
        val etNotes = dialogBinding.findViewById<com.google.android.material.textfield.TextInputEditText>(
            com.propertydealer.app.R.id.etApptNotes)

        val types = arrayOf("Site Visit", "Document Review", "Final Deal", "Follow-up Call")
        spinnerType.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, types).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        scheduledCalendar = Calendar.getInstance().also { it.add(Calendar.HOUR, 1) }
        updateDateTimeButtons(btnDate, btnTime)

        existing?.let {
            etBuyerName.setText(it.buyerName)
            etBuyerPhone.setText(it.buyerPhone)
            etNotes.setText(it.notes)
            scheduledCalendar.timeInMillis = it.scheduledAt
            updateDateTimeButtons(btnDate, btnTime)
            spinnerType.setSelection(types.indexOf(it.visitType).coerceAtLeast(0))
        }

        btnDate.setOnClickListener {
            DatePickerDialog(this, { _, y, m, d ->
                scheduledCalendar.set(y, m, d)
                updateDateTimeButtons(btnDate, btnTime)
            }, scheduledCalendar.get(Calendar.YEAR), scheduledCalendar.get(Calendar.MONTH),
                scheduledCalendar.get(Calendar.DAY_OF_MONTH)).show()
        }
        btnTime.setOnClickListener {
            TimePickerDialog(this, { _, h, min ->
                scheduledCalendar.set(Calendar.HOUR_OF_DAY, h)
                scheduledCalendar.set(Calendar.MINUTE, min)
                updateDateTimeButtons(btnDate, btnTime)
            }, scheduledCalendar.get(Calendar.HOUR_OF_DAY), scheduledCalendar.get(Calendar.MINUTE), false).show()
        }

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Schedule Visit" else "Edit Appointment")
            .setView(dialogBinding)
            .setPositiveButton("Save") { _, _ ->
                val name = etBuyerName.text.toString().trim()
                val phone = etBuyerPhone.text.toString().trim()
                if (name.isEmpty()) { Toast.makeText(this, "Buyer name required", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val appt = (existing ?: Appointment(
                    propertyId = propertyId,
                    propertyName = propertyName,
                    buyerName = name,
                    buyerPhone = phone,
                    scheduledAt = scheduledCalendar.timeInMillis
                )).copy(
                    buyerName = name,
                    buyerPhone = phone,
                    scheduledAt = scheduledCalendar.timeInMillis,
                    visitType = spinnerType.selectedItem.toString(),
                    notes = etNotes.text.toString()
                )
                if (existing == null) viewModel.insertAppointment(appt)
                else viewModel.updateAppointment(appt)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEditDialog(appt: Appointment) = showAddDialog(appt)

    private fun confirmDelete(appt: Appointment) {
        AlertDialog.Builder(this)
            .setTitle("Cancel Appointment?")
            .setMessage("Visit with ${appt.buyerName} on ${formatDateTime(appt.scheduledAt)} will be removed.")
            .setPositiveButton("Delete") { _, _ -> viewModel.deleteAppointment(appt) }
            .setNegativeButton("Keep", null).show()
    }

    private fun updateDateTimeButtons(btnDate: android.widget.Button, btnTime: android.widget.Button) {
        btnDate.text = SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()).format(scheduledCalendar.time)
        btnTime.text = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(scheduledCalendar.time)
    }

    private fun formatDateTime(millis: Long) =
        SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(millis))
}
