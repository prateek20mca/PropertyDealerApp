package com.propertydealer.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.propertydealer.app.data.model.*

@Database(
    entities = [
        Property::class,
        Buyer::class,
        PropertyDocument::class,
        Appointment::class,
        NegotiationEntry::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun propertyDao(): PropertyDao
    abstract fun buyerDao(): BuyerDao
    abstract fun documentDao(): DocumentDao
    abstract fun appointmentDao(): AppointmentDao
    abstract fun negotiationDao(): NegotiationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "property_dealer_db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
