package com.propertydealer.app.firebase

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.propertydealer.app.data.model.*
import kotlinx.coroutines.tasks.await

object FirebaseRepository {

    private val db = FirebaseFirestore.getInstance()

    // All data stored under fixed dealer document (no auth needed)
    private val dealerRef = db.collection("dealers").document(UserSession.FIXED_DEALER_ID)

    private fun propertiesRef() = dealerRef.collection("properties")
    private fun buyersRef() = dealerRef.collection("buyers")
    private fun appointmentsRef() = dealerRef.collection("appointments")
    private fun negotiationsRef() = dealerRef.collection("negotiations")
    private fun settingsRef() = dealerRef.collection("settings").document("guest")

    // ── Properties ────────────────────────────────────────────────────────────
    suspend fun addProperty(property: Property): Result<String> {
        return try {
            val ref = propertiesRef().document()
            val withId = property.copy(id = ref.id, dealerId = UserSession.FIXED_DEALER_ID)
            ref.set(withId).await()
            Result.success(ref.id)
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun updateProperty(property: Property): Result<Unit> {
        return try {
            propertiesRef().document(property.id)
                .set(property.copy(updatedAt = System.currentTimeMillis())).await()
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun deleteProperty(propertyId: String): Result<Unit> {
        return try {
            propertiesRef().document(propertyId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun getProperty(propertyId: String): Property? {
        return try {
            propertiesRef().document(propertyId).get().await().toObject(Property::class.java)
        } catch (e: Exception) { null }
    }

    fun listenToProperties(onUpdate: (List<Property>) -> Unit): ListenerRegistration {
        return propertiesRef()
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, e ->
                if (e != null) { Log.e("FB", "Error", e); return@addSnapshotListener }
                val list = snap?.documents?.mapNotNull { it.toObject(Property::class.java) } ?: emptyList()
                onUpdate(list)
            }
    }

    fun listenForNewProperties(lastSeenAt: Long, onNew: (Property) -> Unit): ListenerRegistration {
        return propertiesRef()
            .whereGreaterThan("createdAt", lastSeenAt)
            .addSnapshotListener { snap, e ->
                if (e != null) return@addSnapshotListener
                snap?.documentChanges?.forEach { change ->
                    if (change.type == com.google.firebase.firestore.DocumentChange.Type.ADDED) {
                        change.document.toObject(Property::class.java).let { onNew(it) }
                    }
                }
            }
    }

    // ── Buyers ────────────────────────────────────────────────────────────────
    suspend fun addBuyer(buyer: Buyer): Result<String> {
        return try {
            val ref = buyersRef().document()
            ref.set(buyer.copy(id = ref.id, dealerId = UserSession.FIXED_DEALER_ID)).await()
            Result.success(ref.id)
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun updateBuyer(buyer: Buyer): Result<Unit> {
        return try {
            buyersRef().document(buyer.id).set(buyer).await()
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun deleteBuyer(buyerId: String): Result<Unit> {
        return try {
            buyersRef().document(buyerId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    fun listenToBuyersForProperty(propertyId: String, onUpdate: (List<Buyer>) -> Unit): ListenerRegistration {
        return buyersRef()
            .whereEqualTo("propertyId", propertyId)
            .addSnapshotListener { snap, e ->
                if (e != null) return@addSnapshotListener
                onUpdate(snap?.documents?.mapNotNull { it.toObject(Buyer::class.java) } ?: emptyList())
            }
    }

    fun listenToAllBuyers(onUpdate: (List<Buyer>) -> Unit): ListenerRegistration {
        return buyersRef()
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, e ->
                if (e != null) return@addSnapshotListener
                onUpdate(snap?.documents?.mapNotNull { it.toObject(Buyer::class.java) } ?: emptyList())
            }
    }

    // ── Guest Settings ────────────────────────────────────────────────────────
    suspend fun getGuestSettings(): GuestSettings? {
        return try {
            settingsRef().get().await().toObject(GuestSettings::class.java)
        } catch (e: Exception) { null }
    }

    suspend fun saveGuestSettings(settings: GuestSettings): Result<Unit> {
        return try {
            settingsRef().set(settings).await()
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    fun listenToGuestSettings(onUpdate: (GuestSettings) -> Unit): ListenerRegistration {
        return settingsRef().addSnapshotListener { snap, e ->
            if (e != null) return@addSnapshotListener
            snap?.toObject(GuestSettings::class.java)?.let { onUpdate(it) }
        }
    }

    // ── Appointments ──────────────────────────────────────────────────────────
    suspend fun addAppointment(appt: Appointment): Result<String> {
        return try {
            val ref = appointmentsRef().document()
            ref.set(appt.copy(id = ref.id, dealerId = UserSession.FIXED_DEALER_ID)).await()
            Result.success(ref.id)
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun updateAppointment(appt: Appointment): Result<Unit> {
        return try {
            appointmentsRef().document(appt.id).set(appt).await()
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun deleteAppointment(apptId: String): Result<Unit> {
        return try {
            appointmentsRef().document(apptId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    fun listenToAppointments(onUpdate: (List<Appointment>) -> Unit): ListenerRegistration {
        return appointmentsRef()
            .orderBy("scheduledAt")
            .addSnapshotListener { snap, e ->
                if (e != null) return@addSnapshotListener
                onUpdate(snap?.documents?.mapNotNull { it.toObject(Appointment::class.java) } ?: emptyList())
            }
    }

    // ── Negotiation ───────────────────────────────────────────────────────────
    suspend fun addNegotiation(entry: NegotiationEntry): Result<String> {
        return try {
            val ref = negotiationsRef().document()
            ref.set(entry.copy(id = ref.id, dealerId = UserSession.FIXED_DEALER_ID)).await()
            Result.success(ref.id)
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun deleteNegotiation(entryId: String): Result<Unit> {
        return try {
            negotiationsRef().document(entryId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    fun listenToNegotiations(propertyId: String, onUpdate: (List<NegotiationEntry>) -> Unit): ListenerRegistration {
        return negotiationsRef()
            .whereEqualTo("propertyId", propertyId)
            .orderBy("enteredAt")
            .addSnapshotListener { snap, e ->
                if (e != null) return@addSnapshotListener
                onUpdate(snap?.documents?.mapNotNull { it.toObject(NegotiationEntry::class.java) } ?: emptyList())
            }
    }
}
