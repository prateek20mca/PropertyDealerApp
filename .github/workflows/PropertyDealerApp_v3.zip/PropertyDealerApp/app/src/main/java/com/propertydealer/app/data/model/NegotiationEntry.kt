package com.propertydealer.app.data.model

data class NegotiationEntry(
    val id: String = "",
    val propertyId: String = "",
    val dealerId: String = "",
    val buyerName: String = "",
    val offeredPrice: Long = 0L,
    val whiteComponent: Long = 0L,
    val blackComponent: Long = 0L,
    val round: Int = 1,
    val party: String = "Buyer",
    val notes: String = "",
    val enteredAt: Long = System.currentTimeMillis()
)
