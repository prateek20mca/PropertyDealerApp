package com.propertydealer.app.data.model

// Firestore-compatible model (no Room annotations needed)
data class Property(
    val id: String = "",
    val dealerId: String = "",
    val name: String = "",
    val address: String = "",
    val locality: String = "",          // Area shown to guests (e.g. "Sector 21, Noida")
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,

    // ── Size ─────────────────────────────────────────────────────────────────
    val width: Double = 0.0,            // feet
    val depth: Double = 0.0,            // feet
    val totalSqFeet: Double = 0.0,      // auto = width × depth
    val totalSqYard: Double = 0.0,      // auto = (width × depth) / 9
    val frontRoadSize: Double = 0.0,    // feet

    // ── Price ────────────────────────────────────────────────────────────────
    val pricePerSqYard: Long = 0L,      // ₹ per sq yard
    val totalPrice: Long = 0L,          // auto = totalSqYard × pricePerSqYard
    val whitePrice: Long = 0L,
    val blackPrice: Long = 0L,
    val sellerAskingPrice: Long = 0L,

    // ── Seller ───────────────────────────────────────────────────────────────
    val sellerName: String = "",
    val sellerPhone: String = "",
    val sellerAltPhone: String = "",
    val sellerEmail: String = "",

    // ── Property Info ────────────────────────────────────────────────────────
    val propertyType: String = "Residential",
    val status: String = "Available",
    val facing: String = "",
    val floor: String = "",
    val totalFloors: String = "",
    val parking: Boolean = false,
    val furnished: String = "Unfurnished",

    // ── Extra Features ───────────────────────────────────────────────────────
    val extraFeatures: String = "",     // comma-separated or free text
    val description: String = "",
    val notes: String = "",

    // ── Commission ───────────────────────────────────────────────────────────
    val commissionPercent: Double = 0.0,
    val commissionAmount: Long = 0L,

    // ── Meta ─────────────────────────────────────────────────────────────────
    val coverImagePath: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
