package com.propertydealer.app.ui.guest

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.propertydealer.app.data.model.GuestSettings
import com.propertydealer.app.data.model.Property
import com.propertydealer.app.databinding.ActivityGuestPropertyDetailBinding
import com.propertydealer.app.firebase.FirebaseRepository
import com.propertydealer.app.utils.FormatUtils
import com.google.firebase.firestore.ListenerRegistration
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class GuestPropertyDetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PROPERTY_ID = "extra_property_id"
        const val EXTRA_DEALER_ID = "extra_dealer_id"
    }

    private lateinit var binding: ActivityGuestPropertyDetailBinding
    private var settingsListener: ListenerRegistration? = null
    private var currentSettings: GuestSettings? = null
    private var propertyId = ""
    private var dealerId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGuestPropertyDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        propertyId = intent.getStringExtra(EXTRA_PROPERTY_ID) ?: ""
        dealerId = intent.getStringExtra(EXTRA_DEALER_ID) ?: ""

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        loadSettings()
        loadProperty()
    }

    private fun loadSettings() {
        settingsListener = FirebaseRepository.listenToGuestSettings() { settings ->
            currentSettings = settings
            loadProperty()
        }
    }

    private fun loadProperty() {
        lifecycleScope.launch {
            // Temporarily use dealer's property ref by passing dealerId
            val snap = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                .collection("dealers").document(dealerId)
                .collection("properties").document(propertyId)
                .get().await()
            val property = snap.toObject(Property::class.java) ?: return@launch
            val settings = currentSettings ?: GuestSettings()
            renderProperty(property, settings)
        }
    }

    private suspend fun com.google.android.gms.tasks.Task<*>.await() =
        kotlinx.coroutines.tasks.await(this as com.google.android.gms.tasks.Task<com.google.firebase.firestore.DocumentSnapshot>)

    private fun renderProperty(p: Property, s: GuestSettings) {
        supportActionBar?.title = p.name
        supportActionBar?.subtitle = p.propertyType

        // Location — show locality only if exact address hidden
        binding.textLocation.text = if (s.showExactAddress) p.address else p.locality.ifEmpty { "Location not disclosed" }

        // Size
        if (s.showSize) {
            binding.cardSize.visibility = View.VISIBLE
            binding.textSize.text = buildString {
                if (p.width > 0 && p.depth > 0) {
                    append("${p.width.toInt()} × ${p.depth.toInt()} ft\n")
                }
                if (p.totalSqFeet > 0) {
                    append("%.1f sq.ft".format(p.totalSqFeet))
                }
                if (p.totalSqYard > 0) {
                    append("  |  %.2f sq.yd".format(p.totalSqYard))
                }
                if (p.frontRoadSize > 0) {
                    append("\nFront Road: ${p.frontRoadSize.toInt()} ft")
                }
            }
        } else binding.cardSize.visibility = View.GONE

        // Facing
        if (s.showFacing && p.facing.isNotEmpty()) {
            binding.textFacing.visibility = View.VISIBLE
            binding.textFacing.text = "Facing: ${p.facing}"
        } else binding.textFacing.visibility = View.GONE

        // Type
        if (s.showPropertyType) {
            binding.textType.text = p.propertyType
        }

        // Price
        if (s.showPrice) {
            binding.cardPrice.visibility = View.VISIBLE
            binding.textPrice.text = FormatUtils.formatCurrencyShort(p.totalPrice)
            if (s.showPricePerSqYard && p.pricePerSqYard > 0) {
                binding.textPricePerSqYard.visibility = View.VISIBLE
                binding.textPricePerSqYard.text = "${FormatUtils.formatCurrencyShort(p.pricePerSqYard)} / sq.yd"
            } else binding.textPricePerSqYard.visibility = View.GONE
        } else binding.cardPrice.visibility = View.GONE

        // Seller name
        if (s.showSellerName && p.sellerName.isNotEmpty()) {
            binding.textSellerName.visibility = View.VISIBLE
            binding.textSellerName.text = "Owner: ${p.sellerName}"
        } else binding.textSellerName.visibility = View.GONE

        // Phone — always masked
        if (s.showPhone && p.sellerPhone.isNotEmpty()) {
            binding.btnCallSeller.visibility = View.VISIBLE
            binding.btnCallSeller.text = "📞 ${FormatUtils.maskPhoneNumber(p.sellerPhone)}"
            binding.btnCallSeller.setOnClickListener {
                startActivity(Intent(Intent.ACTION_DIAL,
                    android.net.Uri.parse("tel:${p.sellerPhone}")))
            }
        } else binding.btnCallSeller.visibility = View.GONE

        // Description
        if (p.description.isNotEmpty()) {
            binding.textDescription.visibility = View.VISIBLE
            binding.textDescription.text = p.description
        } else binding.textDescription.visibility = View.GONE

        // Extra features
        if (p.extraFeatures.isNotEmpty()) {
            binding.textExtraFeatures.visibility = View.VISIBLE
            binding.textExtraFeatures.text = "Features: ${p.extraFeatures}"
        } else binding.textExtraFeatures.visibility = View.GONE

        // Status
        binding.textStatus.text = p.status
        binding.textStatus.setTextColor(FormatUtils.getStatusColor(this, p.status))

        // Contact dealer button
        if (s.allowContactDealer) {
            binding.btnContactDealer.visibility = View.VISIBLE
            binding.btnContactDealer.setOnClickListener {
                val dealerPhone = currentSettings?.dealerPhone ?: ""
                if (dealerPhone.isNotEmpty()) {
                    startActivity(Intent(Intent.ACTION_DIAL,
                        android.net.Uri.parse("tel:$dealerPhone")))
                }
            }
        } else binding.btnContactDealer.visibility = View.GONE
    }

    override fun onDestroy() {
        super.onDestroy()
        settingsListener?.remove()
    }
}
