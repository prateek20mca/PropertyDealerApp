package com.propertydealer.app.utils

import kotlin.math.*

object DistanceCalculator {

    private const val EARTH_RADIUS_KM = 6371.0

    /**
     * Calculates distance between two coordinates using Haversine formula.
     * Returns distance in kilometers.
     */
    fun calculateDistance(
        lat1: Double, lon1: Double,
        lat2: Double, lon2: Double
    ): Double {
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)

        val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2).pow(2)

        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return EARTH_RADIUS_KM * c
    }

    /**
     * Returns a human-readable distance string.
     */
    fun formatDistance(distanceKm: Double): String {
        return if (distanceKm < 1.0) {
            val meters = (distanceKm * 1000).roundToInt()
            "$meters meters"
        } else {
            val km = (distanceKm * 10).roundToInt() / 10.0
            "$km km"
        }
    }

    private fun Double.roundToInt(): Int = Math.round(this).toInt()

    /**
     * Parse coordinates from a string like "26.8505, 75.8069"
     * or from a Google Maps link.
     */
    fun parseCoordinates(input: String): Pair<Double, Double>? {
        return try {
            val cleaned = input.trim()
            if (cleaned.contains(",")) {
                val parts = cleaned.split(",")
                if (parts.size >= 2) {
                    val lat = parts[0].trim().toDouble()
                    val lon = parts[1].trim().toDouble()
                    if (lat in -90.0..90.0 && lon in -180.0..180.0) {
                        Pair(lat, lon)
                    } else null
                } else null
            } else null
        } catch (e: NumberFormatException) {
            null
        }
    }

    /**
     * Build a Google Maps URL for a location.
     */
    fun buildMapsUrl(lat: Double, lon: Double, label: String = ""): String {
        return if (label.isNotEmpty()) {
            "https://maps.google.com/?q=$lat,$lon($label)"
        } else {
            "https://maps.google.com/?q=$lat,$lon"
        }
    }

    /**
     * Build a Google Maps directions URL from one location to another.
     */
    fun buildDirectionsUrl(
        fromLat: Double, fromLon: Double,
        toLat: Double, toLon: Double
    ): String {
        return "https://maps.google.com/maps?saddr=$fromLat,$fromLon&daddr=$toLat,$toLon"
    }
}
