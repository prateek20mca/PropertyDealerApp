package com.propertydealer.app

import android.app.Application
import com.propertydealer.app.firebase.UserSession

class PropertyDealerApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        UserSession.init(this)
    }
}
