package com.propertydealer.app.ui.property

import android.app.Application
import androidx.lifecycle.*
import com.propertydealer.app.data.db.*
import com.propertydealer.app.data.model.*
import kotlinx.coroutines.launch

class PropertyViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = PropertyRepository(
        db.propertyDao(),
        db.buyerDao(),
        db.documentDao(),
        db.appointmentDao(),
        db.negotiationDao()
    )

    val allProperties: LiveData<List<Property>> = repository.allProperties
    val recentProperties: LiveData<List<Property>> = repository.getRecentProperties()
    val upcomingAppointments: LiveData<List<Appointment>> =
        repository.getUpcomingAppointments(System.currentTimeMillis())

    private val _totalCount = MutableLiveData<Int>()
    val totalCount: LiveData<Int> = _totalCount

    private val _availableCount = MutableLiveData<Int>()
    val availableCount: LiveData<Int> = _availableCount

    private val _soldCount = MutableLiveData<Int>()
    val soldCount: LiveData<Int> = _soldCount

    private val _upcomingCount = MutableLiveData<Int>()
    val upcomingCount: LiveData<Int> = _upcomingCount

    init { refreshStats() }

    fun refreshStats() {
        viewModelScope.launch {
            _totalCount.postValue(repository.getTotalCount())
            _availableCount.postValue(repository.getAvailableCount())
            _soldCount.postValue(repository.getSoldCount())
            _upcomingCount.postValue(repository.getUpcomingCount(System.currentTimeMillis()))
        }
    }

    // ── Property CRUD ─────────────────────────────────────────────────────────
    fun insertProperty(property: Property, onResult: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.insertProperty(property)
            refreshStats()
            onResult(id)
        }
    }

    fun updateProperty(property: Property) {
        viewModelScope.launch {
            repository.updateProperty(property)
            refreshStats()
        }
    }

    fun deleteProperty(property: Property) {
        viewModelScope.launch {
            repository.deleteProperty(property)
            refreshStats()
        }
    }

    fun getPropertyById(id: Long, onResult: (Property?) -> Unit) {
        viewModelScope.launch { onResult(repository.getPropertyById(id)) }
    }

    fun getPropertyByIdLive(id: Long): LiveData<Property?> = repository.getPropertyByIdLive(id)

    fun searchProperties(query: String): LiveData<List<Property>> = repository.searchProperties(query)

    fun getPropertiesByStatus(status: String): LiveData<List<Property>> =
        repository.getPropertiesByStatus(status)

    // ── Buyer CRUD ────────────────────────────────────────────────────────────
    fun getBuyersForProperty(propertyId: Long): LiveData<List<Buyer>> =
        repository.getBuyersForProperty(propertyId)

    fun insertBuyer(buyer: Buyer) {
        viewModelScope.launch { repository.insertBuyer(buyer) }
    }

    fun updateBuyer(buyer: Buyer) {
        viewModelScope.launch { repository.updateBuyer(buyer) }
    }

    fun deleteBuyer(buyer: Buyer) {
        viewModelScope.launch { repository.deleteBuyer(buyer) }
    }

    fun getBuyerById(id: Long, onResult: (Buyer?) -> Unit) {
        viewModelScope.launch { onResult(repository.getBuyerById(id)) }
    }

    // ── Documents ─────────────────────────────────────────────────────────────
    fun getDocumentsForProperty(propertyId: Long) = repository.getDocumentsForProperty(propertyId)
    fun getImagesForProperty(propertyId: Long) = repository.getImagesForProperty(propertyId)
    fun getPdfsForProperty(propertyId: Long) = repository.getPdfsForProperty(propertyId)

    fun insertDocument(doc: PropertyDocument, onResult: (Long) -> Unit = {}) {
        viewModelScope.launch { onResult(repository.insertDocument(doc)) }
    }

    fun deleteDocument(doc: PropertyDocument, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteDocument(doc)
            onDeleted()
        }
    }

    fun setCoverImage(doc: PropertyDocument) {
        viewModelScope.launch { repository.setCoverImage(doc) }
    }

    // ── Appointments ──────────────────────────────────────────────────────────
    fun getAllAppointments() = repository.getAllAppointments()
    fun getAppointmentsForProperty(propertyId: Long) = repository.getAppointmentsForProperty(propertyId)

    fun insertAppointment(appt: Appointment, onResult: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.insertAppointment(appt)
            refreshStats()
            onResult(id)
        }
    }

    fun updateAppointment(appt: Appointment) {
        viewModelScope.launch {
            repository.updateAppointment(appt)
            refreshStats()
        }
    }

    fun deleteAppointment(appt: Appointment) {
        viewModelScope.launch {
            repository.deleteAppointment(appt)
            refreshStats()
        }
    }

    // ── Negotiation ───────────────────────────────────────────────────────────
    fun getNegotiationsForProperty(propertyId: Long) = repository.getNegotiationsForProperty(propertyId)

    fun insertNegotiation(entry: NegotiationEntry) {
        viewModelScope.launch { repository.insertNegotiation(entry) }
    }

    fun deleteNegotiation(entry: NegotiationEntry) {
        viewModelScope.launch { repository.deleteNegotiation(entry) }
    }
}

class PropertyViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PropertyViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return PropertyViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
