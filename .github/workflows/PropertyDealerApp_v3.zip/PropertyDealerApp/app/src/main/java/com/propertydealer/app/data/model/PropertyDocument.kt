package com.propertydealer.app.data.model

data class PropertyDocument(
    val id: String = "",
    val propertyId: String = "",
    val dealerId: String = "",
    val fileName: String = "",
    val filePath: String = "",
    val fileType: String = "",
    val fileSize: Long = 0L,
    val caption: String = "",
    val docCategory: String = "General",
    val isCover: Boolean = false,
    val uploadedAt: Long = System.currentTimeMillis()
)
