package com.propertydealer.app.ui.negotiation

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.propertydealer.app.data.model.NegotiationEntry
import com.propertydealer.app.databinding.ActivityNegotiationBinding
import com.propertydealer.app.ui.adapters.NegotiationAdapter
import com.propertydealer.app.ui.property.PropertyViewModel
import com.propertydealer.app.ui.property.PropertyViewModelFactory
import com.propertydealer.app.utils.FormatUtils

class NegotiationActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PROPERTY_ID = "extra_property_id"
        const val EXTRA_PROPERTY_NAME = "extra_property_name"
    }

    private lateinit var binding: ActivityNegotiationBinding
    private val viewModel: PropertyViewModel by viewModels { PropertyViewModelFactory(application) }
    private lateinit var adapter: NegotiationAdapter
    private var propertyId: Long = 0L
    private var propertyName: String = ""
    private var round = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNegotiationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        propertyId = intent.getLongExtra(EXTRA_PROPERTY_ID, 0L)
        propertyName = intent.getStringExtra(EXTRA_PROPERTY_NAME) ?: ""

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Negotiation Log"
        supportActionBar?.subtitle = propertyName
        binding.toolbar.setNavigationOnClickListener { finish() }

        adapter = NegotiationAdapter { entry -> confirmDeleteEntry(entry) }
        binding.recyclerNegotiations.apply {
            layoutManager = LinearLayoutManager(this@NegotiationActivity)
            adapter = this@NegotiationActivity.adapter
        }

        viewModel.getNegotiationsForProperty(propertyId).observe(this) { list ->
            adapter.submitList(list)
            round = (list.maxOfOrNull { it.round } ?: 0) + 1
            binding.textViewEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            updateSummary(list)
        }

        binding.btnAddBuyerOffer.setOnClickListener { showAddDialog("Buyer") }
        binding.btnAddSellerOffer.setOnClickListener { showAddDialog("Seller") }
    }

    private fun showAddDialog(party: String) {
        val view = layoutInflater.inflate(com.propertydealer.app.R.layout.dialog_negotiation_entry, null)
        val etBuyer = view.findViewById<com.google.android.material.textfield.TextInputEditText>(
            com.propertydealer.app.R.id.etNegBuyerName)
        val etPrice = view.findViewById<com.google.android.material.textfield.TextInputEditText>(
            com.propertydealer.app.R.id.etNegPrice)
        val etWhite = view.findViewById<com.google.android.material.textfield.TextInputEditText>(
            com.propertydealer.app.R.id.etNegWhite)
        val etNotes = view.findViewById<com.google.android.material.textfield.TextInputEditText>(
            com.propertydealer.app.R.id.etNegNotes)

        if (party == "Seller") etBuyer.setText(propertyName)

        AlertDialog.Builder(this)
            .setTitle("Log $party Offer – Round $round")
            .setView(view)
            .setPositiveButton("Add") { _, _ ->
                val price = etPrice.text.toString().toLongOrNull()
                if (price == null) { Toast.makeText(this, "Enter valid price", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val white = etWhite.text.toString().toLongOrNull() ?: 0L
                viewModel.insertNegotiation(NegotiationEntry(
                    propertyId = propertyId,
                    buyerName = etBuyer.text.toString().ifEmpty { party },
                    offeredPrice = price,
                    whiteComponent = white,
                    blackComponent = price - white,
                    round = round,
                    party = party,
                    notes = etNotes.text.toString()
                ))
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun updateSummary(list: List<NegotiationEntry>) {
        val buyerOffers = list.filter { it.party == "Buyer" }
        val sellerOffers = list.filter { it.party == "Seller" }
        val highestBuyer = buyerOffers.maxOfOrNull { it.offeredPrice } ?: 0L
        val lowestSeller = sellerOffers.minOfOrNull { it.offeredPrice } ?: 0L
        val gap = lowestSeller - highestBuyer

        binding.textHighestBuyer.text = FormatUtils.formatCurrencyShort(highestBuyer)
        binding.textLowestSeller.text = if (lowestSeller > 0) FormatUtils.formatCurrencyShort(lowestSeller) else "–"
        binding.textGap.text = if (gap > 0) "Gap: ${FormatUtils.formatCurrencyShort(gap)}" else if (highestBuyer > 0 && lowestSeller > 0) "✅ Deal possible!" else "–"
    }

    private fun confirmDeleteEntry(entry: NegotiationEntry) {
        AlertDialog.Builder(this)
            .setTitle("Delete this entry?")
            .setPositiveButton("Delete") { _, _ -> viewModel.deleteNegotiation(entry) }
            .setNegativeButton("Cancel", null).show()
    }
}
