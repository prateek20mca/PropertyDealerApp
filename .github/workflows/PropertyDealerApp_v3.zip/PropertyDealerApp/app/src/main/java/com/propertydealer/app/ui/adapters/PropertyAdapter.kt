package com.propertydealer.app.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.propertydealer.app.data.model.Property
import com.propertydealer.app.databinding.ItemPropertyBinding
import com.propertydealer.app.utils.FormatUtils

class PropertyAdapter(
    private val onItemClick: (Property) -> Unit,
    private val onEditClick: (Property) -> Unit,
    private val onDeleteClick: (Property) -> Unit
) : ListAdapter<Property, PropertyAdapter.PropertyViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PropertyViewHolder {
        val binding = ItemPropertyBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PropertyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PropertyViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class PropertyViewHolder(private val binding: ItemPropertyBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(property: Property) {
            binding.textViewName.text = property.name
            binding.textViewAddress.text = property.address
            binding.textViewPrice.text = FormatUtils.formatCurrencyShort(property.totalPrice)
            binding.textViewType.text = property.propertyType
            binding.textViewStatus.text = property.status
            binding.textViewStatus.setTextColor(
                ContextCompat.getColor(binding.root.context, FormatUtils.getStatusColor(property.status))
            )

            if (property.area.isNotEmpty()) {
                binding.textViewArea.text = "${property.area} ${property.areaUnit}"
            } else {
                binding.textViewArea.text = ""
            }

            binding.textViewDate.text = FormatUtils.formatDate(property.updatedAt)

            binding.root.setOnClickListener { onItemClick(property) }
            binding.buttonEdit.setOnClickListener { onEditClick(property) }
            binding.buttonDelete.setOnClickListener { onDeleteClick(property) }
        }
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Property>() {
            override fun areItemsTheSame(oldItem: Property, newItem: Property) =
                oldItem.id == newItem.id

            override fun areContentsTheSame(oldItem: Property, newItem: Property) =
                oldItem == newItem
        }
    }
}
