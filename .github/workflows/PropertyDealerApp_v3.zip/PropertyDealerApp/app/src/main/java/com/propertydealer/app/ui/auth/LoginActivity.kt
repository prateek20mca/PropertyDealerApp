package com.propertydealer.app.ui.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.propertydealer.app.databinding.ActivityLoginBinding
import com.propertydealer.app.firebase.UserSession
import com.propertydealer.app.ui.guest.GuestHomeActivity
import com.propertydealer.app.ui.property.MainActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // If already logged in (remember me), skip login screen
        if (UserSession.isLoggedIn && UserSession.rememberMe) {
            navigateAfterLogin()
            return
        }

        setupButtons()
    }

    private fun setupButtons() {
        // Dealer Login button
        binding.btnDealerLogin.setOnClickListener {
            val userId = binding.etUserId.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()
            val remember = binding.checkboxRememberMe.isChecked

            if (userId.isEmpty() || password.isEmpty()) {
                showError("Please enter User ID and Password")
                return@setOnClickListener
            }

            if (userId == UserSession.DEALER_USER_ID && password == UserSession.DEALER_PASSWORD) {
                UserSession.loginAsDealer(remember)
                navigateAfterLogin()
            } else {
                showError("Invalid User ID or Password")
                binding.etPassword.text?.clear()
            }
        }

        // Guest Login — just tap and enter
        binding.btnGuestLogin.setOnClickListener {
            UserSession.loginAsGuest()
            startActivity(Intent(this, GuestHomeActivity::class.java))
            finish()
        }
    }

    private fun showError(msg: String) {
        binding.textError.text = msg
        binding.textError.visibility = View.VISIBLE
    }

    private fun navigateAfterLogin() {
        val intent = when {
            UserSession.isDealer -> Intent(this, MainActivity::class.java)
            else -> Intent(this, GuestHomeActivity::class.java)
        }
        startActivity(intent)
        finish()
    }
}
