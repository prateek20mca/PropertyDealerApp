package com.propertydealer.app.ui.document

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.tabs.TabLayout
import com.propertydealer.app.data.model.PropertyDocument
import com.propertydealer.app.databinding.ActivityDocumentManagerBinding
import com.propertydealer.app.ui.adapters.DocumentAdapter
import com.propertydealer.app.ui.property.PropertyViewModel
import com.propertydealer.app.ui.property.PropertyViewModelFactory
import com.propertydealer.app.utils.FileUtils
import java.io.File

class DocumentManagerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PROPERTY_ID = "extra_property_id"
        const val EXTRA_PROPERTY_NAME = "extra_property_name"
    }

    private lateinit var binding: ActivityDocumentManagerBinding
    private val viewModel: PropertyViewModel by viewModels { PropertyViewModelFactory(application) }
    private lateinit var documentAdapter: DocumentAdapter
    private var propertyId: Long = 0L
    private var propertyName: String = ""
    private var currentCameraUri: Uri? = null

    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) currentCameraUri?.let { saveDocumentFromUri(it, "image/jpeg") }
    }

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        uris.forEach { saveDocumentFromUri(it, contentResolver.getType(it) ?: "image/jpeg") }
    }

    private val pdfLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { saveDocumentFromUri(it, "application/pdf") }
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
        if (perms.values.all { it }) showAddDialog()
        else Toast.makeText(this, "Permission required to add documents", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDocumentManagerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        propertyId = intent.getLongExtra(EXTRA_PROPERTY_ID, 0L)
        propertyName = intent.getStringExtra(EXTRA_PROPERTY_NAME) ?: ""

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Documents"
        supportActionBar?.subtitle = propertyName
        binding.toolbar.setNavigationOnClickListener { finish() }

        setupAdapter()
        setupTabs()
        loadTab(0)

        binding.fabAddDocument.setOnClickListener { checkPermsAndAdd() }
    }

    private fun setupAdapter() {
        documentAdapter = DocumentAdapter(
            onImageClick = { openDocument(it) },
            onDeleteClick = { confirmDelete(it) },
            onSetCoverClick = { viewModel.setCoverImage(it) },
            onShareClick = { shareDocument(it) }
        )
        binding.recyclerDocuments.apply {
            layoutManager = GridLayoutManager(this@DocumentManagerActivity, 2)
            adapter = documentAdapter
        }
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) { loadTab(tab?.position ?: 0) }
            override fun onTabUnselected(t: TabLayout.Tab?) {}
            override fun onTabReselected(t: TabLayout.Tab?) {}
        })
    }

    private fun loadTab(pos: Int) {
        val liveData = when (pos) {
            1 -> viewModel.getImagesForProperty(propertyId)
            2 -> viewModel.getPdfsForProperty(propertyId)
            else -> viewModel.getDocumentsForProperty(propertyId)
        }
        liveData.observe(this) { docs ->
            documentAdapter.submitList(docs)
            binding.textViewEmpty.visibility = if (docs.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun checkPermsAndAdd() {
        val needed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.CAMERA)
        else
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA)
        val missing = needed.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) showAddDialog() else permLauncher.launch(missing.toTypedArray())
    }

    private fun showAddDialog() {
        AlertDialog.Builder(this)
            .setTitle("Add Document")
            .setItems(arrayOf("📷 Take Photo", "🖼️ Gallery (multi-select)", "📄 Import PDF")) { _, which ->
                when (which) {
                    0 -> {
                        val file = FileUtils.createImageFile(this, propertyId)
                        currentCameraUri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
                        cameraLauncher.launch(currentCameraUri!!)
                    }
                    1 -> galleryLauncher.launch("image/*")
                    2 -> pdfLauncher.launch("application/pdf")
                }
            }.show()
    }

    private fun saveDocumentFromUri(uri: Uri, mimeType: String) {
        try {
            val dest = if (mimeType == "application/pdf") FileUtils.createPdfFile(this, propertyId)
                       else FileUtils.createImageFile(this, propertyId)
            contentResolver.openInputStream(uri)?.use { it.copyTo(dest.outputStream()) }
            val name = FileUtils.getFileName(this, uri) ?: dest.name
            val doc = PropertyDocument(
                propertyId = propertyId,
                fileName = name,
                filePath = dest.absolutePath,
                fileType = mimeType,
                fileSize = dest.length(),
                docCategory = if (mimeType == "application/pdf") "Legal" else "Photo"
            )
            viewModel.insertDocument(doc) {
                runOnUiThread { Toast.makeText(this, "Saved: $name", Toast.LENGTH_SHORT).show() }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openDocument(doc: PropertyDocument) {
        val file = File(doc.filePath)
        if (!file.exists()) { Toast.makeText(this, "File not found", Toast.LENGTH_SHORT).show(); return }
        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
        startActivity(Intent.createChooser(
            Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, doc.fileType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "Open with"
        ))
    }

    private fun shareDocument(doc: PropertyDocument) {
        val file = File(doc.filePath)
        if (!file.exists()) return
        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
        startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND).apply {
                type = doc.fileType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "Property document: ${doc.fileName} ($propertyName)")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "Share via"
        ))
    }

    private fun confirmDelete(doc: PropertyDocument) {
        AlertDialog.Builder(this)
            .setTitle("Delete '${doc.fileName}'?")
            .setMessage("The file will be permanently deleted.")
            .setPositiveButton("Delete") { _, _ ->
                File(doc.filePath).delete()
                viewModel.deleteDocument(doc)
            }
            .setNegativeButton("Cancel", null).show()
    }
}
