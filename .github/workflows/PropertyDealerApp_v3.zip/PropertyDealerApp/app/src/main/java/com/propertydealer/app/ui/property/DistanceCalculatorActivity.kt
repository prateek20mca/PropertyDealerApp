package com.propertydealer.app.ui.property

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.propertydealer.app.databinding.ActivityDistanceCalculatorBinding
import com.propertydealer.app.utils.DistanceCalculator

class DistanceCalculatorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PROPERTY_LAT = "extra_prop_lat"
        const val EXTRA_PROPERTY_LON = "extra_prop_lon"
        const val EXTRA_PROPERTY_NAME = "extra_prop_name"
        const val EXTRA_PROPERTY_ADDRESS = "extra_prop_address"
    }

    private lateinit var binding: ActivityDistanceCalculatorBinding
    private var propertyLat: Double = 0.0
    private var propertyLon: Double = 0.0
    private var propertyName: String = ""
    private var propertyAddress: String = ""

    private val locationPermissionRequest = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        ) {
            useCurrentLocation()
        } else {
            Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDistanceCalculatorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        propertyLat = intent.getDoubleExtra(EXTRA_PROPERTY_LAT, 0.0)
        propertyLon = intent.getDoubleExtra(EXTRA_PROPERTY_LON, 0.0)
        propertyName = intent.getStringExtra(EXTRA_PROPERTY_NAME) ?: ""
        propertyAddress = intent.getStringExtra(EXTRA_PROPERTY_ADDRESS) ?: ""

        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            title = "Distance Calculator"
            setDisplayHomeAsUpEnabled(true)
        }
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.textViewPropertyInfo.text = "📍 Property: $propertyName\n$propertyAddress"

        if (propertyLat != 0.0 && propertyLon != 0.0) {
            binding.textViewPropertyCoords.text = "Coordinates: $propertyLat, $propertyLon"
        } else {
            binding.textViewPropertyCoords.text = "⚠️ No coordinates saved for this property"
        }

        setupButtons()
    }

    private fun setupButtons() {
        binding.buttonUseCurrentLocation.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED
            ) {
                useCurrentLocation()
            } else {
                locationPermissionRequest.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            }
        }

        binding.buttonCalculate.setOnClickListener {
            calculateDistance()
        }

        binding.buttonOpenDirections.setOnClickListener {
            openDirections()
        }

        binding.buttonOpenPropertyOnMap.setOnClickListener {
            openPropertyOnMap()
        }
    }

    private fun useCurrentLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) return

        val fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                binding.editTextFromCoords.setText("${location.latitude}, ${location.longitude}")
                Toast.makeText(this, "Current location loaded", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Could not get location. Please enter manually.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun calculateDistance() {
        val fromInput = binding.editTextFromCoords.text.toString().trim()
        if (fromInput.isEmpty()) {
            binding.editTextFromCoords.error = "Please enter coordinates or use current location"
            return
        }

        val fromCoords = DistanceCalculator.parseCoordinates(fromInput)
        if (fromCoords == null) {
            binding.editTextFromCoords.error = "Invalid format. Use: latitude, longitude (e.g. 26.850, 75.806)"
            return
        }

        if (propertyLat == 0.0 && propertyLon == 0.0) {
            val toInput = binding.editTextToCoords.text.toString().trim()
            if (toInput.isEmpty()) {
                binding.editTextToCoords.error = "Please enter property coordinates"
                return
            }
            val toCoords = DistanceCalculator.parseCoordinates(toInput)
            if (toCoords == null) {
                binding.editTextToCoords.error = "Invalid format."
                return
            }
            showDistance(fromCoords.first, fromCoords.second, toCoords.first, toCoords.second)
        } else {
            showDistance(fromCoords.first, fromCoords.second, propertyLat, propertyLon)
        }
    }

    private fun showDistance(fromLat: Double, fromLon: Double, toLat: Double, toLon: Double) {
        val distanceKm = DistanceCalculator.calculateDistance(fromLat, fromLon, toLat, toLon)
        val formatted = DistanceCalculator.formatDistance(distanceKm)

        binding.textViewResult.text = "📏 Distance: $formatted"
        binding.cardResult.visibility = android.view.View.VISIBLE

        // Save for directions button
        binding.buttonOpenDirections.tag = "$fromLat,$fromLon,$toLat,$toLon"

        val shareText = buildString {
            appendLine("📍 Distance from your location to:")
            appendLine("🏠 $propertyName")
            appendLine("📌 $propertyAddress")
            appendLine()
            appendLine("📏 Distance: $formatted")
            if (toLat != 0.0)
                appendLine("🗺️ Map: ${DistanceCalculator.buildMapsUrl(toLat, toLon, propertyName)}")
        }
        binding.buttonShareDistance.setOnClickListener {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, shareText)
            }
            startActivity(Intent.createChooser(intent, "Share Distance"))
        }
    }

    private fun openDirections() {
        val tag = binding.buttonOpenDirections.tag as? String ?: return
        val parts = tag.split(",")
        if (parts.size < 4) return
        val url = DistanceCalculator.buildDirectionsUrl(
            parts[0].toDouble(), parts[1].toDouble(),
            parts[2].toDouble(), parts[3].toDouble()
        )
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun openPropertyOnMap() {
        if (propertyLat != 0.0 && propertyLon != 0.0) {
            val uri = Uri.parse("geo:$propertyLat,$propertyLon?q=$propertyLat,$propertyLon($propertyName)")
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } else if (propertyAddress.isNotEmpty()) {
            val uri = Uri.parse("geo:0,0?q=${Uri.encode(propertyAddress)}")
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    }
}
