package com.propertydealer.app.ui.property

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.propertydealer.app.databinding.ActivitySearchBinding
import com.propertydealer.app.ui.adapters.PropertyAdapter

class SearchActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySearchBinding
    private val viewModel: PropertyViewModel by viewModels {
        PropertyViewModelFactory(application)
    }
    private lateinit var adapter: PropertyAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Search Properties"
        binding.toolbar.setNavigationOnClickListener { finish() }

        adapter = PropertyAdapter(
            onItemClick = { property ->
                val intent = Intent(this, PropertyDetailActivity::class.java)
                intent.putExtra(PropertyDetailActivity.EXTRA_PROPERTY_ID, property.id)
                startActivity(intent)
            },
            onEditClick = { property ->
                val intent = Intent(this, AddEditPropertyActivity::class.java)
                intent.putExtra(AddEditPropertyActivity.EXTRA_PROPERTY_ID, property.id)
                startActivity(intent)
            },
            onDeleteClick = { property ->
                viewModel.deleteProperty(property)
            }
        )

        binding.recyclerViewResults.apply {
            layoutManager = LinearLayoutManager(this@SearchActivity)
            adapter = this@SearchActivity.adapter
        }

        binding.editTextSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString()?.trim() ?: ""
                if (query.length >= 2) {
                    viewModel.searchProperties(query).observe(this@SearchActivity) { list ->
                        adapter.submitList(list)
                        binding.textViewNoResults.visibility =
                            if (list.isEmpty()) View.VISIBLE else View.GONE
                    }
                }
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.editTextSearch.requestFocus()
    }
}
