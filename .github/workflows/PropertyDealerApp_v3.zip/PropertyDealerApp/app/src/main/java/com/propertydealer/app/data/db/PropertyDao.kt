package com.propertydealer.app.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.propertydealer.app.data.model.Property

@Dao
interface PropertyDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(property: Property): Long

    @Update
    suspend fun update(property: Property)

    @Delete
    suspend fun delete(property: Property)

    @Query("SELECT * FROM properties ORDER BY updatedAt DESC")
    fun getAllProperties(): LiveData<List<Property>>

    @Query("SELECT * FROM properties WHERE id = :id")
    suspend fun getPropertyById(id: Long): Property?

    @Query("SELECT * FROM properties WHERE id = :id")
    fun getPropertyByIdLive(id: Long): LiveData<Property?>

    @Query("SELECT * FROM properties WHERE status = :status ORDER BY updatedAt DESC")
    fun getPropertiesByStatus(status: String): LiveData<List<Property>>

    @Query("SELECT * FROM properties WHERE propertyType = :type ORDER BY updatedAt DESC")
    fun getPropertiesByType(type: String): LiveData<List<Property>>

    @Query("""
        SELECT * FROM properties WHERE 
        name LIKE '%' || :query || '%' OR 
        address LIKE '%' || :query || '%' OR
        sellerName LIKE '%' || :query || '%' OR
        description LIKE '%' || :query || '%'
        ORDER BY updatedAt DESC
    """)
    fun searchProperties(query: String): LiveData<List<Property>>

    @Query("SELECT COUNT(*) FROM properties")
    suspend fun getTotalCount(): Int

    @Query("SELECT COUNT(*) FROM properties WHERE status = 'Available'")
    suspend fun getAvailableCount(): Int

    @Query("SELECT COUNT(*) FROM properties WHERE status = 'Sold'")
    suspend fun getSoldCount(): Int

    @Query("SELECT * FROM properties ORDER BY updatedAt DESC LIMIT :limit")
    fun getRecentProperties(limit: Int = 5): LiveData<List<Property>>
}
