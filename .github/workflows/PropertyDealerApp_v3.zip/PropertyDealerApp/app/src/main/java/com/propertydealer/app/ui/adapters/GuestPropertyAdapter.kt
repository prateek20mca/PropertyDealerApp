package com.propertydealer.app.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.propertydealer.app.R
import com.propertydealer.app.data.model.GuestSettings
import com.propertydealer.app.data.model.Property
import com.propertydealer.app.utils.FormatUtils
import java.text.SimpleDateFormat
import java.util.*

class GuestPropertyAdapter(
    private val onClick: (Property) -> Unit
) : ListAdapter<Property, GuestPropertyAdapter.ViewHolder>(DiffCallback()) {

    private var settings = GuestSettings()

    fun updateSettings(s: GuestSettings) {
        settings = s
        notifyDataSetChanged()
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val textName: TextView = view.findViewById(R.id.textGuestPropName)
        val textLocation: TextView = view.findViewById(R.id.textGuestPropLocation)
        val textSize: TextView = view.findViewById(R.id.textGuestPropSize)
        val textPrice: TextView = view.findViewById(R.id.textGuestPropPrice)
        val textType: TextView = view.findViewById(R.id.textGuestPropType)
        val textFacing: TextView = view.findViewById(R.id.textGuestPropFacing)
        val textStatus: TextView = view.findViewById(R.id.textGuestPropStatus)
        val textDate: TextView = view.findViewById(R.id.textGuestPropDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_guest_property, parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val p = getItem(position)
        val s = settings

        holder.textName.text = p.name
        holder.textLocation.text = if (s.showExactAddress) p.address else p.locality.ifEmpty { "Location on request" }

        if (s.showSize && (p.totalSqYard > 0 || p.width > 0)) {
            holder.textSize.visibility = View.VISIBLE
            holder.textSize.text = buildString {
                if (p.width > 0 && p.depth > 0) append("${p.width.toInt()}×${p.depth.toInt()} ft  |  ")
                if (p.totalSqFeet > 0) append("%.0f sq.ft  |  ".format(p.totalSqFeet))
                if (p.totalSqYard > 0) append("%.2f sq.yd".format(p.totalSqYard))
            }
        } else holder.textSize.visibility = View.GONE

        if (s.showPrice && p.totalPrice > 0) {
            holder.textPrice.visibility = View.VISIBLE
            holder.textPrice.text = buildString {
                append(FormatUtils.formatCurrencyShort(p.totalPrice))
                if (s.showPricePerSqYard && p.pricePerSqYard > 0)
                    append("  •  ${FormatUtils.formatCurrencyShort(p.pricePerSqYard)}/sq.yd")
            }
        } else holder.textPrice.visibility = View.GONE

        if (s.showPropertyType) holder.textType.text = p.propertyType else holder.textType.visibility = View.GONE

        if (s.showFacing && p.facing.isNotEmpty()) {
            holder.textFacing.visibility = View.VISIBLE
            holder.textFacing.text = "Facing: ${p.facing}"
        } else holder.textFacing.visibility = View.GONE

        holder.textStatus.text = p.status
        holder.textDate.text = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(p.createdAt))

        holder.itemView.setOnClickListener { onClick(p) }
    }

    class DiffCallback : DiffUtil.ItemCallback<Property>() {
        override fun areItemsTheSame(a: Property, b: Property) = a.id == b.id
        override fun areContentsTheSame(a: Property, b: Property) = a == b
    }
}
