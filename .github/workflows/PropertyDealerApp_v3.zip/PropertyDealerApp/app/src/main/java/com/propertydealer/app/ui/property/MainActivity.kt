package com.propertydealer.app.ui.property

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.chip.Chip
import com.google.android.material.snackbar.Snackbar
import com.propertydealer.app.R
import com.propertydealer.app.databinding.ActivityMainBinding
import com.propertydealer.app.ui.adapters.PropertyAdapter

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: PropertyViewModel by viewModels {
        PropertyViewModelFactory(application)
    }
    private lateinit var propertyAdapter: PropertyAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerView()
        setupSearch()
        setupFilters()
        setupFab()
        observeData()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_search -> {
                startActivity(Intent(this, SearchActivity::class.java)); true
            }
            R.id.action_appointments_all -> {
                startActivity(Intent(this, com.propertydealer.app.ui.appointment.AppointmentActivity::class.java).apply {
                    putExtra("mode", com.propertydealer.app.ui.appointment.AppointmentActivity.MODE_ALL)
                }); true
            }
            R.id.action_emi_calc -> {
                startActivity(Intent(this, com.propertydealer.app.ui.tools.EmiCalculatorActivity::class.java)); true
            }
            R.id.action_compare -> {
                startActivity(Intent(this, com.propertydealer.app.ui.tools.PropertyCompareActivity::class.java)); true
            }
            R.id.action_guest_settings -> {
                startActivity(Intent(this, com.propertydealer.app.ui.settings.DealerSettingsActivity::class.java)); true
            }
            R.id.action_logout -> {
                androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("Logout?")
                    .setPositiveButton("Logout") { _, _ ->
                        com.propertydealer.app.firebase.UserSession.forceLogout()
                        startActivity(Intent(this, com.propertydealer.app.ui.auth.LoginActivity::class.java))
                        finishAffinity()
                    }
                    .setNegativeButton("Cancel", null).show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshStats()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = "My Properties"
    }

    private fun setupRecyclerView() {
        propertyAdapter = PropertyAdapter(
            onItemClick = { property ->
                val intent = Intent(this, PropertyDetailActivity::class.java)
                intent.putExtra(PropertyDetailActivity.EXTRA_PROPERTY_ID, property.id)
                startActivity(intent)
            },
            onEditClick = { property ->
                val intent = Intent(this, AddEditPropertyActivity::class.java)
                intent.putExtra(AddEditPropertyActivity.EXTRA_PROPERTY_ID, property.id)
                startActivity(intent)
            },
            onDeleteClick = { property ->
                viewModel.deleteProperty(property)
                Snackbar.make(binding.root, "Property deleted", Snackbar.LENGTH_LONG)
                    .setAction("UNDO") { viewModel.insertProperty(property) }
                    .show()
            }
        )
        binding.recyclerViewProperties.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = propertyAdapter
        }
    }

    private fun setupSearch() {
        binding.editTextSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                viewModel.setSearchQuery(s?.toString() ?: "")
                observeFilteredProperties()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.imageViewClearSearch.setOnClickListener {
            binding.editTextSearch.setText("")
        }
    }

    private fun setupFilters() {
        // Status filter chips
        val statusList = listOf("All", "Available", "Sold", "Pending", "Under Negotiation")
        statusList.forEach { status ->
            val chip = Chip(this).apply {
                text = status
                isCheckable = true
                isChecked = status == "All"
                setOnClickListener {
                    viewModel.setStatusFilter(status)
                    observeFilteredProperties()
                }
            }
            binding.chipGroupStatus.addView(chip)
        }

        // Type filter
        val typeAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_dropdown_item_1line,
            listOf("All", "Residential", "Commercial", "Industrial", "Agricultural", "Plot", "Office", "Shop")
        )
        binding.autoCompleteType.setAdapter(typeAdapter)
        binding.autoCompleteType.setOnItemClickListener { _, _, _, _ ->
            val selected = binding.autoCompleteType.text.toString()
            viewModel.setTypeFilter(selected)
            observeFilteredProperties()
        }
    }

    private fun setupFab() {
        binding.fabAddProperty.setOnClickListener {
            startActivity(Intent(this, AddEditPropertyActivity::class.java))
        }
    }

    private fun observeData() {
        viewModel.allProperties.observe(this) { properties ->
            propertyAdapter.submitList(properties)
            binding.textViewEmptyState.visibility =
                if (properties.isEmpty()) View.VISIBLE else View.GONE
            binding.recyclerViewProperties.visibility =
                if (properties.isEmpty()) View.GONE else View.VISIBLE
        }

        viewModel.totalCount.observe(this) { count ->
            binding.textViewTotalCount.text = count.toString()
        }

        viewModel.availableCount.observe(this) { count ->
            binding.textViewAvailableCount.text = count.toString()
        }

        viewModel.soldCount.observe(this) { count ->
            binding.textViewSoldCount.text = count.toString()
        }

        viewModel.operationStatus.observe(this) { msg ->
            if (!msg.isNullOrEmpty()) {
                Snackbar.make(binding.root, msg, Snackbar.LENGTH_SHORT).show()
            }
        }
    }

    private fun observeFilteredProperties() {
        viewModel.getFilteredProperties().observe(this) { properties ->
            propertyAdapter.submitList(properties)
            binding.textViewEmptyState.visibility =
                if (properties.isEmpty()) View.VISIBLE else View.GONE
            binding.recyclerViewProperties.visibility =
                if (properties.isEmpty()) View.GONE else View.VISIBLE
        }
    }
}
