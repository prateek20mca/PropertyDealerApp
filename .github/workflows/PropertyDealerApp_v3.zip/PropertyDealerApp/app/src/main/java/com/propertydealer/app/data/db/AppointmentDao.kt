package com.propertydealer.app.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.propertydealer.app.data.model.Appointment

@Dao
interface AppointmentDao {
    @Query("SELECT * FROM appointments ORDER BY scheduledAt ASC")
    fun getAllAppointments(): LiveData<List<Appointment>>

    @Query("SELECT * FROM appointments WHERE propertyId = :propertyId ORDER BY scheduledAt ASC")
    fun getAppointmentsForProperty(propertyId: Long): LiveData<List<Appointment>>

    @Query("SELECT * FROM appointments WHERE scheduledAt >= :fromTime AND scheduledAt <= :toTime ORDER BY scheduledAt ASC")
    fun getAppointmentsInRange(fromTime: Long, toTime: Long): LiveData<List<Appointment>>

    @Query("SELECT * FROM appointments WHERE status = 'Scheduled' AND scheduledAt >= :now ORDER BY scheduledAt ASC LIMIT 10")
    fun getUpcomingAppointments(now: Long): LiveData<List<Appointment>>

    @Query("SELECT COUNT(*) FROM appointments WHERE status = 'Scheduled' AND scheduledAt >= :now")
    suspend fun getUpcomingCount(now: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(appointment: Appointment): Long

    @Update
    suspend fun update(appointment: Appointment)

    @Delete
    suspend fun delete(appointment: Appointment)

    @Query("SELECT * FROM appointments WHERE id = :id")
    suspend fun getById(id: Long): Appointment?
}
