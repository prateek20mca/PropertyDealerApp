package com.propertydealer.app.ui.tools

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import com.propertydealer.app.databinding.ActivityEmiCalculatorBinding
import kotlin.math.pow

class EmiCalculatorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEmiCalculatorBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEmiCalculatorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "EMI Calculator"
        binding.toolbar.setNavigationOnClickListener { finish() }

        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { calculate() }
        }
        binding.etLoanAmount.addTextChangedListener(watcher)
        binding.etInterestRate.addTextChangedListener(watcher)
        binding.etTenureYears.addTextChangedListener(watcher)
        binding.seekBarRate.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) binding.etInterestRate.setText(progress.toString())
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
        })
        binding.seekBarTenure.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) binding.etTenureYears.setText(progress.toString())
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
        })

        // Preset quick buttons
        binding.btnPreset10L.setOnClickListener { binding.etLoanAmount.setText("1000000") }
        binding.btnPreset25L.setOnClickListener { binding.etLoanAmount.setText("2500000") }
        binding.btnPreset50L.setOnClickListener { binding.etLoanAmount.setText("5000000") }
        binding.btnPreset1Cr.setOnClickListener { binding.etLoanAmount.setText("10000000") }
    }

    private fun calculate() {
        val principal = binding.etLoanAmount.text.toString().toDoubleOrNull() ?: return
        val annualRate = binding.etInterestRate.text.toString().toDoubleOrNull() ?: return
        val years = binding.etTenureYears.text.toString().toIntOrNull() ?: return

        if (principal <= 0 || annualRate <= 0 || years <= 0) return

        val r = annualRate / 12 / 100   // monthly rate
        val n = years * 12              // months

        val emi = principal * r * (1 + r).pow(n) / ((1 + r).pow(n) - 1)
        val totalPayment = emi * n
        val totalInterest = totalPayment - principal

        binding.textEmi.text = formatCurrency(emi)
        binding.textTotalPayment.text = formatCurrency(totalPayment)
        binding.textTotalInterest.text = formatCurrency(totalInterest)
        binding.textPrincipal.text = formatCurrency(principal)

        // Interest ratio for pie-like bar
        val interestPct = (totalInterest / totalPayment * 100).toInt()
        binding.progressInterest.progress = interestPct
        binding.textInterestPct.text = "$interestPct% Interest"
        binding.textPrincipalPct.text = "${100 - interestPct}% Principal"

        // Amortization summary
        val yr5 = if (years >= 5) {
            val paid5 = emi * 60
            val bal5 = principal * (1+r).pow(60) - emi * ((1+r).pow(60) - 1) / r
            "After 5 yrs: Paid ${formatCurrency(paid5)}, Balance ${formatCurrency(bal5)}"
        } else ""
        binding.textAmortSummary.text = yr5
    }

    private fun formatCurrency(amount: Double): String {
        return when {
            amount >= 1_00_00_000 -> "₹%.2f Cr".format(amount / 1_00_00_000)
            amount >= 1_00_000 -> "₹%.2f L".format(amount / 1_00_000)
            else -> "₹%.0f".format(amount)
        }
    }
}
