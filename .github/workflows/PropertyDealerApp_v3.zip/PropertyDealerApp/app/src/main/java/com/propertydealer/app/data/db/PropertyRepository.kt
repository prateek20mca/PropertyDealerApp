package com.propertydealer.app.data.db

import com.propertydealer.app.data.model.*

class PropertyRepository(
    private val propertyDao: PropertyDao,
    private val buyerDao: BuyerDao,
    private val documentDao: DocumentDao,
    private val appointmentDao: AppointmentDao,
    private val negotiationDao: NegotiationDao
) {
    // ── Property ──────────────────────────────────────────────────────────────
    val allProperties = propertyDao.getAllProperties()

    suspend fun insertProperty(property: Property): Long = propertyDao.insert(property)
    suspend fun updateProperty(property: Property) = propertyDao.update(property)
    suspend fun deleteProperty(property: Property) = propertyDao.delete(property)
    suspend fun getPropertyById(id: Long) = propertyDao.getPropertyById(id)
    fun getPropertyByIdLive(id: Long) = propertyDao.getPropertyByIdLive(id)
    fun getPropertiesByStatus(status: String) = propertyDao.getPropertiesByStatus(status)
    fun getPropertiesByType(type: String) = propertyDao.getPropertiesByType(type)
    fun searchProperties(query: String) = propertyDao.searchProperties(query)
    suspend fun getTotalCount() = propertyDao.getTotalCount()
    suspend fun getAvailableCount() = propertyDao.getAvailableCount()
    suspend fun getSoldCount() = propertyDao.getSoldCount()
    fun getRecentProperties() = propertyDao.getRecentProperties()

    // ── Buyer ─────────────────────────────────────────────────────────────────
    fun getBuyersForProperty(propertyId: Long) = buyerDao.getBuyersForProperty(propertyId)
    suspend fun insertBuyer(buyer: Buyer): Long = buyerDao.insert(buyer)
    suspend fun updateBuyer(buyer: Buyer) = buyerDao.update(buyer)
    suspend fun deleteBuyer(buyer: Buyer) = buyerDao.delete(buyer)
    suspend fun getBuyerById(id: Long) = buyerDao.getBuyerById(id)
    suspend fun getBuyerCount(propertyId: Long) = buyerDao.getBuyerCountForProperty(propertyId)
    suspend fun getHighestOffer(propertyId: Long) = buyerDao.getHighestOfferForProperty(propertyId)

    // ── Documents ─────────────────────────────────────────────────────────────
    fun getDocumentsForProperty(propertyId: Long) = documentDao.getDocumentsForProperty(propertyId)
    fun getImagesForProperty(propertyId: Long) = documentDao.getImagesForProperty(propertyId)
    fun getPdfsForProperty(propertyId: Long) = documentDao.getPdfsForProperty(propertyId)
    suspend fun insertDocument(doc: PropertyDocument): Long = documentDao.insert(doc)
    suspend fun updateDocument(doc: PropertyDocument) = documentDao.update(doc)
    suspend fun deleteDocument(doc: PropertyDocument) = documentDao.delete(doc)
    suspend fun setCoverImage(doc: PropertyDocument) {
        documentDao.clearCoverForProperty(doc.propertyId)
        documentDao.update(doc.copy(isCover = true))
    }
    suspend fun getDocumentCount(propertyId: Long) = documentDao.getDocumentCount(propertyId)

    // ── Appointments ──────────────────────────────────────────────────────────
    fun getAllAppointments() = appointmentDao.getAllAppointments()
    fun getAppointmentsForProperty(propertyId: Long) = appointmentDao.getAppointmentsForProperty(propertyId)
    fun getUpcomingAppointments(now: Long) = appointmentDao.getUpcomingAppointments(now)
    suspend fun getUpcomingCount(now: Long) = appointmentDao.getUpcomingCount(now)
    suspend fun insertAppointment(appt: Appointment): Long = appointmentDao.insert(appt)
    suspend fun updateAppointment(appt: Appointment) = appointmentDao.update(appt)
    suspend fun deleteAppointment(appt: Appointment) = appointmentDao.delete(appt)

    // ── Negotiation History ───────────────────────────────────────────────────
    fun getNegotiationsForProperty(propertyId: Long) = negotiationDao.getNegotiationsForProperty(propertyId)
    suspend fun insertNegotiation(entry: NegotiationEntry): Long = negotiationDao.insert(entry)
    suspend fun deleteNegotiation(entry: NegotiationEntry) = negotiationDao.delete(entry)
    suspend fun getHighestBuyerOffer(propertyId: Long) = negotiationDao.getHighestBuyerOffer(propertyId)
    suspend fun getRoundCount(propertyId: Long) = negotiationDao.getRoundCount(propertyId)
}
