package com.propertydealer.app

import android.app.Application
import com.propertydealer.app.data.db.AppDatabase

class PropertyDealerApplication : Application() {

    val database: AppDatabase by lazy {
        AppDatabase.getDatabase(this)
    }

    override fun onCreate() {
        super.onCreate()
    }
}
