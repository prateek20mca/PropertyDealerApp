package com.propertydealer.app.data.model

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(
    tableName = "property_documents",
    foreignKeys = [ForeignKey(
        entity = Property::class,
        parentColumns = ["id"],
        childColumns = ["propertyId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("propertyId")]
)
data class PropertyDocument(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val propertyId: Long,
    val fileName: String,
    val filePath: String,         // Internal storage absolute path
    val fileType: String,         // "image/jpeg", "image/png", "application/pdf"
    val fileSize: Long = 0L,      // Bytes
    val caption: String = "",
    val docCategory: String = "General", // General, Legal, FloorPlan, Photo, Agreement
    val isCover: Boolean = false,
    val uploadedAt: Long = System.currentTimeMillis()
) : Parcelable
