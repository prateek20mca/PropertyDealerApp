package com.propertydealer.app.data.model

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(
    tableName = "negotiation_history",
    foreignKeys = [ForeignKey(
        entity = Property::class,
        parentColumns = ["id"],
        childColumns = ["propertyId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("propertyId")]
)
data class NegotiationEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val propertyId: Long,
    val buyerName: String,
    val offeredPrice: Long,
    val whiteComponent: Long = 0L,
    val blackComponent: Long = 0L,
    val round: Int = 1,
    val party: String = "Buyer",    // "Buyer" or "Seller" or "Dealer"
    val notes: String = "",
    val enteredAt: Long = System.currentTimeMillis()
) : Parcelable
