package com.propertydealer.app.data.model

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "properties")
data class Property(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val address: String,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val totalPrice: Long,
    val whitePrice: Long,
    val blackPrice: Long,
    val sellerAskingPrice: Long = 0L,       // Seller's asking/demand price
    val sellerName: String,
    val sellerPhone: String,
    val sellerEmail: String = "",
    val sellerAltPhone: String = "",
    val description: String = "",
    val propertyType: String = "Residential",
    val area: String = "",
    val areaUnit: String = "sq.ft",
    val status: String = "Available",       // Available, Sold, Pending, Under Negotiation
    val facing: String = "",
    val floor: String = "",
    val totalFloors: String = "",
    val parking: Boolean = false,
    val furnished: String = "Unfurnished",  // Unfurnished, Semi, Fully
    val commissionPercent: Double = 0.0,    // Dealer's commission percentage
    val commissionAmount: Long = 0L,        // Calculated commission
    val coverImagePath: String = "",        // Path to cover/first image
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) : Parcelable
