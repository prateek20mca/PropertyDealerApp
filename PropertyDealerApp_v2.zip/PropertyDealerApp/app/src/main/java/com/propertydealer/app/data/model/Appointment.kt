package com.propertydealer.app.data.model

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(
    tableName = "appointments",
    foreignKeys = [ForeignKey(
        entity = Property::class,
        parentColumns = ["id"],
        childColumns = ["propertyId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("propertyId")]
)
data class Appointment(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val propertyId: Long,
    val propertyName: String,
    val buyerName: String,
    val buyerPhone: String,
    val scheduledAt: Long,          // Timestamp of visit
    val durationMinutes: Int = 60,
    val visitType: String = "Site Visit", // Site Visit, Document, Final Deal, Follow-up
    val status: String = "Scheduled",     // Scheduled, Completed, Cancelled, Rescheduled
    val notes: String = "",
    val reminderMinutes: Int = 60,  // Alert X minutes before
    val createdAt: Long = System.currentTimeMillis()
) : Parcelable
