package com.propertydealer.app.ui.property

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.propertydealer.app.data.model.Property
import com.propertydealer.app.databinding.ActivityAddEditPropertyBinding
import com.propertydealer.app.utils.FormatUtils

class AddEditPropertyActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PROPERTY_ID = "extra_property_id"
    }

    private lateinit var binding: ActivityAddEditPropertyBinding
    private val viewModel: PropertyViewModel by viewModels {
        PropertyViewModelFactory(application)
    }

    private var editPropertyId: Long = -1L
    private var existingProperty: Property? = null
    private var currentLat: Double = 0.0
    private var currentLon: Double = 0.0
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private val locationPermissionRequest = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        ) {
            getCurrentLocation()
        } else {
            Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddEditPropertyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        editPropertyId = intent.getLongExtra(EXTRA_PROPERTY_ID, -1L)
        val isEditing = editPropertyId != -1L

        setupToolbar(isEditing)
        setupDropdowns()
        setupButtons()

        if (isEditing) {
            loadPropertyForEdit(editPropertyId)
        }
    }

    private fun setupToolbar(isEditing: Boolean) {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            title = if (isEditing) "Edit Property" else "Add New Property"
            setDisplayHomeAsUpEnabled(true)
        }
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupDropdowns() {
        val propertyTypes = listOf("Residential", "Commercial", "Industrial", "Agricultural", "Plot", "Office", "Shop", "Warehouse")
        binding.autoCompletePropertyType.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, propertyTypes)
        )
        binding.autoCompletePropertyType.setText("Residential", false)

        val areaUnits = listOf("sq.ft", "sq.m", "sq.yard", "Bigha", "Acre", "Hectare")
        binding.autoCompleteAreaUnit.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, areaUnits)
        )
        binding.autoCompleteAreaUnit.setText("sq.ft", false)

        val facingOptions = listOf("North", "South", "East", "West", "North-East", "North-West", "South-East", "South-West")
        binding.autoCompleteFacing.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, facingOptions)
        )

        val furnishedOptions = listOf("Unfurnished", "Semi-Furnished", "Fully Furnished")
        binding.autoCompleteFurnished.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, furnishedOptions)
        )
        binding.autoCompleteFurnished.setText("Unfurnished", false)

        val statusOptions = listOf("Available", "Sold", "Pending", "Under Negotiation")
        binding.autoCompleteStatus.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, statusOptions)
        )
        binding.autoCompleteStatus.setText("Available", false)
    }

    private fun setupButtons() {
        binding.buttonGetLocation.setOnClickListener {
            checkAndGetLocation()
        }

        binding.buttonSave.setOnClickListener {
            saveProperty()
        }
    }

    private fun checkAndGetLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED
        ) {
            getCurrentLocation()
        } else {
            locationPermissionRequest.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    private fun getCurrentLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) return

        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            if (location != null) {
                currentLat = location.latitude
                currentLon = location.longitude
                binding.editTextLatitude.setText(location.latitude.toString())
                binding.editTextLongitude.setText(location.longitude.toString())
                Toast.makeText(this, "Location captured!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Could not get current location. Please enter manually.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun loadPropertyForEdit(propertyId: Long) {
        viewModel.getFilteredProperties().removeObservers(this)
        // Load from live data by ID
        val db = com.propertydealer.app.data.db.AppDatabase.getDatabase(application)
        db.propertyDao().getPropertyByIdLive(propertyId).observe(this) { property ->
            property?.let {
                existingProperty = it
                populateForm(it)
            }
        }
    }

    private fun populateForm(property: Property) {
        binding.editTextPropertyName.setText(property.name)
        binding.editTextAddress.setText(property.address)
        binding.editTextLatitude.setText(if (property.latitude != 0.0) property.latitude.toString() else "")
        binding.editTextLongitude.setText(if (property.longitude != 0.0) property.longitude.toString() else "")
        binding.editTextSellerAskingPrice.setText(if (property.sellerAskingPrice > 0) property.sellerAskingPrice.toString() else "")
        binding.editTextTotalPrice.setText(property.totalPrice.toString())
        binding.editTextWhitePrice.setText(property.whitePrice.toString())
        binding.editTextBlackPrice.setText(property.blackPrice.toString())
        binding.editTextSellerName.setText(property.sellerName)
        binding.editTextSellerPhone.setText(property.sellerPhone)
        binding.editTextSellerAltPhone.setText(property.sellerAltPhone)
        binding.editTextSellerEmail.setText(property.sellerEmail)
        binding.editTextArea.setText(property.area)
        binding.autoCompleteAreaUnit.setText(property.areaUnit, false)
        binding.autoCompletePropertyType.setText(property.propertyType, false)
        binding.autoCompleteFacing.setText(property.facing, false)
        binding.editTextFloor.setText(property.floor)
        binding.editTextTotalFloors.setText(property.totalFloors)
        binding.switchParking.isChecked = property.parking
        binding.autoCompleteFurnished.setText(property.furnished, false)
        binding.autoCompleteStatus.setText(property.status, false)
        binding.editTextDescription.setText(property.description)
        binding.editTextNotes.setText(property.notes)
        currentLat = property.latitude
        currentLon = property.longitude
    }

    private fun saveProperty() {
        val name = binding.editTextPropertyName.text.toString().trim()
        val address = binding.editTextAddress.text.toString().trim()
        val totalPriceStr = binding.editTextTotalPrice.text.toString().trim()
        val whitePriceStr = binding.editTextWhitePrice.text.toString().trim()
        val blackPriceStr = binding.editTextBlackPrice.text.toString().trim()
        val sellerName = binding.editTextSellerName.text.toString().trim()
        val sellerPhone = binding.editTextSellerPhone.text.toString().trim()

        // Validation
        if (name.isEmpty()) {
            binding.tilPropertyName.error = "Property name is required"
            return
        }
        if (address.isEmpty()) {
            binding.tilAddress.error = "Address is required"
            return
        }
        if (totalPriceStr.isEmpty()) {
            binding.tilTotalPrice.error = "Total price is required"
            return
        }
        if (sellerName.isEmpty()) {
            binding.tilSellerName.error = "Seller name is required"
            return
        }
        if (sellerPhone.isEmpty() || sellerPhone.length < 10) {
            binding.tilSellerPhone.error = "Valid seller phone is required"
            return
        }

        // Clear errors
        binding.tilPropertyName.error = null
        binding.tilAddress.error = null
        binding.tilTotalPrice.error = null
        binding.tilSellerName.error = null
        binding.tilSellerPhone.error = null

        val latStr = binding.editTextLatitude.text.toString().trim()
        val lonStr = binding.editTextLongitude.text.toString().trim()
        val lat = latStr.toDoubleOrNull() ?: currentLat
        val lon = lonStr.toDoubleOrNull() ?: currentLon

        val totalPrice = FormatUtils.parseAmount(totalPriceStr)
        val whitePrice = if (whitePriceStr.isEmpty()) 0L else FormatUtils.parseAmount(whitePriceStr)
        val blackPrice = if (blackPriceStr.isEmpty()) 0L else FormatUtils.parseAmount(blackPriceStr)
        val sellerAskingPrice = binding.editTextSellerAskingPrice.text.toString().trim().let {
            if (it.isEmpty()) 0L else FormatUtils.parseAmount(it)
        }
        val commissionPct = binding.editTextCommissionPercent.text.toString().toDoubleOrNull() ?: 0.0
        val commissionAmt = (totalPrice * commissionPct / 100).toLong()

        val property = Property(
            id = if (editPropertyId != -1L) editPropertyId else 0L,
            name = name,
            address = address,
            latitude = lat,
            longitude = lon,
            totalPrice = totalPrice,
            whitePrice = whitePrice,
            blackPrice = blackPrice,
            sellerAskingPrice = sellerAskingPrice,
            commissionPercent = commissionPct,
            commissionAmount = commissionAmt,
            sellerName = sellerName,
            sellerPhone = sellerPhone,
            sellerAltPhone = binding.editTextSellerAltPhone.text.toString().trim(),
            sellerEmail = binding.editTextSellerEmail.text.toString().trim(),
            propertyType = binding.autoCompletePropertyType.text.toString(),
            area = binding.editTextArea.text.toString().trim(),
            areaUnit = binding.autoCompleteAreaUnit.text.toString(),
            facing = binding.autoCompleteFacing.text.toString().trim(),
            floor = binding.editTextFloor.text.toString().trim(),
            totalFloors = binding.editTextTotalFloors.text.toString().trim(),
            parking = binding.switchParking.isChecked,
            furnished = binding.autoCompleteFurnished.text.toString(),
            status = binding.autoCompleteStatus.text.toString(),
            description = binding.editTextDescription.text.toString().trim(),
            notes = binding.editTextNotes.text.toString().trim(),
            updatedAt = System.currentTimeMillis()
        )

        if (editPropertyId != -1L) {
            viewModel.updateProperty(property)
            Toast.makeText(this, "Property updated!", Toast.LENGTH_SHORT).show()
        } else {
            viewModel.insertProperty(property)
            Toast.makeText(this, "Property added!", Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
