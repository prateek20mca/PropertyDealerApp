package com.propertydealer.app.data.model

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(
    tableName = "buyers",
    foreignKeys = [
        ForeignKey(
            entity = Property::class,
            parentColumns = ["id"],
            childColumns = ["propertyId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["propertyId"])]
)
data class Buyer(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val propertyId: Long,
    val name: String,
    val phone: String,
    val email: String = "",
    val offeredPrice: Long,
    val offeredWhitePrice: Long = 0,
    val offeredBlackPrice: Long = 0,
    val notes: String = "",
    val status: String = "Interested",  // Interested, Negotiating, Accepted, Rejected
    val createdAt: Long = System.currentTimeMillis()
) : Parcelable
